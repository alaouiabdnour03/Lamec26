import { createClient } from '@supabase/supabase-js';

let supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL || 'https://placeholder-url.supabase.co';
let supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

supabaseUrl = supabaseUrl.replace(/^[\"']|[\"']$/g, '').trim();
supabaseAnonKey = supabaseAnonKey.replace(/^[\"']|[\"']$/g, '').trim();
if (!supabaseUrl.startsWith('http')) { supabaseUrl = 'https://' + supabaseUrl; }
// Remove /rest/v1 or trailing slash if present
supabaseUrl = supabaseUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');

const isPlaceholder = 
  !(import.meta as any).env.VITE_SUPABASE_URL || 
  (import.meta as any).env.VITE_SUPABASE_URL.includes('placeholder') || 
  (import.meta as any).env.VITE_SUPABASE_URL.includes('YOUR_SUPABASE') ||
  !(import.meta as any).env.VITE_SUPABASE_ANON_KEY ||
  (import.meta as any).env.VITE_SUPABASE_ANON_KEY.includes('placeholder') || 
  (import.meta as any).env.VITE_SUPABASE_ANON_KEY.includes('YOUR_SUPABASE');

const realSupabase = createClient(
  supabaseUrl || 'https://placeholder-url.supabase.co',
  supabaseAnonKey || 'placeholder-key'
);

export type ClientData = {
  id: string;
  company_name: string;
  ice: string;
  access_code: string;
  cnss_employees: string;
  email: string;
  phone: string;
  ca: string;
  sector: string;
  activity: string;
  custom_activity: string;
  created_at: string;
};

export type DiagnosticData = {
  id: string;
  client_id: string;
  status: 'draft' | 'completed' | 'report_generated';
  current_step: number;
  data: any;
  report_url: string | null;
  report_filename: string | null;
  report_size_kb: number | null;
  created_at: string;
  updated_at: string;
};

/* ─── SEED DATA ─── */
const SEED_CLIENTS: ClientData[] = [
  {
    id: 'demo-client-uuid-123',
    company_name: 'Hôtel Dunes & Soleil (Seed Demo)',
    ice: '123456789012345',
    access_code: 'LMC-2026',
    cnss_employees: '12 salariés',
    email: 'demo@hoteldunes.ma',
    phone: '+212 6 00 11 22 33',
    ca: '< 10M MAD',
    sector: 'tourisme',
    activity: 'hotel3',
    custom_activity: 'Hôtel de charme 3 étoiles à Ouarzazate',
    created_at: new Date().toISOString()
  }
];

const SEED_DIAGNOSTICS: DiagnosticData[] = [
  {
    id: 'demo-diag-uuid-abc',
    client_id: 'demo-client-uuid-123',
    status: 'report_generated',
    current_step: 999,
    data: {
      raisonSociale: 'Hôtel Dunes & Soleil',
      nomDirigeant: 'Hicham',
      phoneEmail: 'demo@hoteldunes.ma',
      effectif: '1-5',
      nbrLaboratoires: '1',
      typologieOffres: ['standard'],
      chiffrageMethode: ['excel_lent'],
      difficultesClosing: 'Manque de réactivité commerciale et de relances structurées.',
      suiviAvancement: ['memoire'],
      gestionImprevus: ['verbal'],
      evaluationSucces: ['verbal_client'],
      planificationExtras: ['sms_whatsapp'],
      adequationLogistique: 'Assez d\'accord',
      digitalisation: {
        crm: '1',
        chiffrage: '2',
        recettes: '1',
        personnel: '2',
        stocks: '1',
        flotte: '1',
        facturation: '2'
      },
      silosInformation: 'Les réservations de Booking et directes ne sont pas partagées en temps réel.',
      clotureFinanciere: ['estimation_brute'],
      painPoint1: 'Overbooking fréquent',
      painPoint2: 'Pas de suivi des stocks d\'ingrédients',
      painPoint3: 'Perte de temps dans le planning des extras'
    },
    report_url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    report_filename: 'Rapport_Diagnostic_Hôtel_Dunes_Soleil.pdf',
    report_size_kb: 152,
    created_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
    updated_at: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
  }
];

/* ─── ROBUST QUERY BUILDER ─── */
class RobustQueryBuilder {
  private tableName: string;
  private columnsToSelect: string = '*';
  private insertData: any[] | null = null;
  private updateData: any | null = null;
  private filters: Array<{ column: string; value: any }> = [];
  private orderConfig: { column: string; ascending: boolean } | null = null;
  private isSingle: boolean = false;
  private isMaybeSingle: boolean = false;

  constructor(tableName: string) {
    this.tableName = tableName;
  }

  select(columns: string = '*') {
    this.columnsToSelect = columns;
    return this;
  }

  insert(values: any[]) {
    this.insertData = values;
    return this;
  }

  update(values: any) {
    this.updateData = values;
    return this;
  }

  eq(column: string, value: any) {
    this.filters.push({ column, value });
    return this;
  }

  order(column: string, options?: { ascending?: boolean }) {
    this.orderConfig = { column, ascending: options?.ascending !== false };
    return this;
  }

  single() {
    this.isSingle = true;
    return this;
  }

  maybeSingle() {
    this.isMaybeSingle = true;
    return this;
  }

  private async execute(): Promise<{ data: any; error: any }> {
    if (isPlaceholder) {
      console.log(`[Supabase Proxy] Placeholder detected for ${this.tableName}, using local fallback.`);
      return this.executeLocalFallback();
    }

    try {
      let query = realSupabase.from(this.tableName) as any;
      if (this.insertData) {
        query = query.insert(this.insertData);
      } else if (this.updateData) {
        query = query.update(this.updateData);
      } else {
        query = query.select(this.columnsToSelect);
      }

      for (const filter of this.filters) {
        query = query.eq(filter.column, filter.value);
      }

      if (this.orderConfig) {
        query = query.order(this.orderConfig.column, { ascending: this.orderConfig.ascending });
      }

      if (this.isSingle) {
        query = query.single();
      } else if (this.isMaybeSingle) {
        query = query.maybeSingle();
      }

      const result = await query;
      if (result.error) {
        console.warn(`[Supabase Proxy] Real query error on "${this.tableName}":`, result.error);
        throw result.error;
      }
      return result;
    } catch (err) {
      console.warn(`[Supabase Proxy] falling back to localStorage for "${this.tableName}" due to query failure:`, err);
      return this.executeLocalFallback();
    }
  }

  private async executeLocalFallback(): Promise<{ data: any; error: any }> {
    const key = `lamec_${this.tableName}`;
    let items: any[] = [];
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        items = JSON.parse(raw);
      } else {
        // Init with seed data if localStorage is empty
        if (this.tableName === 'clients') {
          items = [...SEED_CLIENTS];
          localStorage.setItem(key, JSON.stringify(items));
        } else if (this.tableName === 'diagnostics') {
          items = [...SEED_DIAGNOSTICS];
          localStorage.setItem(key, JSON.stringify(items));
        }
      }
    } catch (e) {
      console.error("Error reading localStorage fallback:", e);
    }

    // Handle INSERT
    if (this.insertData) {
      const insertedRows: any[] = [];
      for (const row of this.insertData) {
        const newRow = {
          id: row.id || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          ...row
        };
        items.push(newRow);
        insertedRows.push(newRow);
      }
      localStorage.setItem(key, JSON.stringify(items));
      return { data: this.isSingle ? insertedRows[0] : insertedRows, error: null };
    }

    // Handle UPDATE
    if (this.updateData) {
      const updatedRows: any[] = [];
      const updatedItems = items.map(item => {
        let matches = true;
        for (const filter of this.filters) {
          if (String(item[filter.column]) !== String(filter.value)) {
            matches = false;
            break;
          }
        }
        if (matches) {
          const updated = {
            ...item,
            ...this.updateData,
            updated_at: new Date().toISOString()
          };
          updatedRows.push(updated);
          return updated;
        }
        return item;
      });

      localStorage.setItem(key, JSON.stringify(updatedItems));
      return { data: this.isSingle ? updatedRows[0] : updatedRows, error: null };
    }

    // Handle SELECT / QUERY
    let filtered = [...items];

    for (const filter of this.filters) {
      filtered = filtered.filter(item => String(item[filter.column]) === String(filter.value));
    }

    if (this.orderConfig) {
      const { column, ascending } = this.orderConfig;
      filtered.sort((a, b) => {
        const valA = a[column];
        const valB = b[column];
        if (valA === undefined || valA === null) return ascending ? 1 : -1;
        if (valB === undefined || valB === null) return ascending ? -1 : 1;
        if (valA < valB) return ascending ? -1 : 1;
        if (valA > valB) return ascending ? 1 : -1;
        return 0;
      });
    }

    if (this.isSingle) {
      if (filtered.length === 0) {
        return { data: null, error: { message: 'Row not found', code: 'PGRST116' } };
      }
      return { data: filtered[0], error: null };
    }

    if (this.isMaybeSingle) {
      if (filtered.length === 0) {
        return { data: null, error: null };
      }
      return { data: filtered[0], error: null };
    }

    return { data: filtered, error: null };
  }

  // Allow direct awaiting
  then<TResult1 = any, TResult2 = never>(
    onfulfilled?: ((value: any) => TResult1 | PromiseLike<TResult1>) | null,
    onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null
  ): Promise<TResult1 | TResult2> {
    return this.execute().then(onfulfilled, onrejected);
  }
}

/* ─── ROBUST STORAGE ─── */
const inMemoryFiles = new Map<string, string>();

class RobustStorage {
  from(bucketName: string) {
    return {
      upload: async (filePath: string, blob: Blob, options?: any) => {
        if (isPlaceholder) {
          const objectUrl = URL.createObjectURL(blob);
          inMemoryFiles.set(`${bucketName}/${filePath}`, objectUrl);
          return { data: { path: filePath }, error: null };
        }

        try {
          const { data, error } = await realSupabase.storage
            .from(bucketName)
            .upload(filePath, blob, options);
          if (error) throw error;
          return { data, error: null };
        } catch (err) {
          console.warn("[Robust Storage] falling back to ObjectURL memory due to failure:", err);
          const objectUrl = URL.createObjectURL(blob);
          inMemoryFiles.set(`${bucketName}/${filePath}`, objectUrl);
          return { data: { path: filePath }, error: null };
        }
      },
      getPublicUrl: (filePath: string) => {
        const key = `${bucketName}/${filePath}`;
        if (inMemoryFiles.has(key)) {
          return { data: { publicUrl: inMemoryFiles.get(key)! } };
        }

        if (isPlaceholder) {
          return { data: { publicUrl: '' } };
        }

        try {
          const { data } = realSupabase.storage.from(bucketName).getPublicUrl(filePath);
          return { data };
        } catch (err) {
          console.warn("[Robust Storage] falling back to default dummy URL:", err);
          return { data: { publicUrl: '' } };
        }
      }
    };
  }
}

/* ─── ROBUST CLIENT ─── */
class RobustSupabaseClient {
  from(tableName: string) {
    return new RobustQueryBuilder(tableName);
  }

  get storage() {
    return new RobustStorage();
  }
}

export const supabase = new RobustSupabaseClient();
