import React, { useState, useEffect } from 'react';
import { Download, AlertCircle, Loader2, ArrowLeft, CheckCircle2, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from './lib/supabase';

const PRINTER = "https://smida78.pythonanywhere.com";

const GEMINI_CONTENT_PROMPT = `You are a senior digital-transformation consultant (cabinet Lameconseil). I give you a client diagnostic as JSON. You do NOT write any code. You output ONLY ONE JSON object (no markdown, no fences, no prose outside the JSON) that provides the AUTHORED FRENCH CONTENT and the 7 expert "observe" scores. A separate fixed template turns your JSON into the Word report, so never mention formatting, never mention the cabinet name, and never write any date or year anywhere (not on a cover, not in prose — use neutral phrasing like "le présent diagnostic"). The IGMD percentage and its band are computed by the template, NOT by you: in your prose, describe the maturity level with words only (e.g. "un niveau basique", "un niveau intermédiaire") and never invent a percentage number.
SCALES: the client self-assessed each process 1-4 in "digitalisation" (1 Manuel/Papier, 2 Excel/Word, 3 Logiciel standard, 4 ERP intégré). You provide "observe" = your 7 independent expert scores on 1-5 (1 Artisanal/Verbal, 2 Bureautique basique, 3 Outils spécialisés non intégrés, 4 Digitalisé & intégré, 5 Digitalisé & intelligent (IA)), derived by cross-referencing the qualitative answers (rubric below). Usually 1-4; 5 only if genuine automation/AI is described.
THE 7 PROCESSES — your "processes" array MUST have exactly 7 items IN THIS EXACT ORDER (item 1 = crm, 2 = chiffrage, 3 = recettes, 4 = personnel, 5 = stocks, 6 = flotte, 7 = facturation):
1 CRM / Prospection / Devis <- typologieOffres, difficultesClosing
2 Chiffrage & Devis d'ingrédients <- chiffrageMethode, difficultesClosing
3 Fiches techniques & Recettes <- gestionImprevus, silosInformation
4 Planification du personnel & Extras <- planificationExtras
5 Suivi stocks, achats & DLC <- adequationLogistique
6 Logistique, flotte & matériel <- adequationLogistique, planificationExtras
7 Facturation & compta. analytique <- clotureFinanciere, evaluationSucces
LOW-maturity signals (nudge observe down): manuel, excel_lent, remises_aveugles, memoire, verbal, reedition, sms_whatsapp, dysfonctionnements, verbal_client, pas_de_suivi, estimation_brute, impossible_automatisation.
HIGH-maturity signals (confirm/up): jalons, kanban_deconnecte, centralise, debriefing, interim_externe, scrupuleux, sur-mesure, modulaire.
Use silosInformation + the 3 painPoints for the transversal paragraphs and to choose priorities. Default sector = traiteur / événementiel unless the answers clearly imply another activity (in which case adapt the vocabulary to that sector while keeping the same 7 process labels).
CODE LEGEND (decode these short codes in your head so your prose cites the real situation):
effectif 1-5=1 à 5 pers; 6-15=6 à 15; 16-50=16 à 50; 50+=+50. nbrLaboratoires 1=site unique; multi=multi-sites. typologieOffres standard=Formules clés en main; sur-mesure=Devis 100% sur-mesure reconstruits à zéro; modulaire=Prestations modulaires décorrélées. chiffrageMethode manuel=Calcul manuel + coefficient global; excel_lent=Aucune simulation dynamique, tout recalcul refait sur Excel; remises_aveugles=Remises globales sans visibilité sur la marge nette. suiviAvancement jalons=Jalons manuels; memoire=Suivi sur la mémoire du chef de projet; kanban_deconnecte=Outil collaboratif déconnecté des fiches cuisine. gestionImprevus verbal=Transmission verbale/note (risque d'oubli); reedition=Réédition papier + redistribution manuelle; centralise=Système centralisé temps réel. evaluationSucces verbal_client=Retours verbaux uniquement; debriefing=Débriefing formalisé des écarts; pas_de_suivi=Aucun suivi post-événement. planificationExtras sms_whatsapp=SMS/WhatsApp + planning Excel; interim_externe=Agences d'intérim externes; dysfonctionnements=Erreurs d'horaires/fiches de poste/pointages. clotureFinanciere scrupuleux=Formule (Produits - Charges) projet par projet sous 48h; estimation_brute=Marge brute sur nourriture seulement; impossible_automatisation=Calcul impossible à automatiser.
PRIORITY per process (optional field "priority"): one of "Quick win" / "Amélioration continue" / "Chantier stratégique". A low observe or a process tied to a painPoint -> "Quick win"; a mid observe needing structuring -> "Amélioration continue"; a structural/integration dependency -> "Chantier stratégique". If omitted, a default rule applies server-side.
OUTPUT JSON SCHEMA (exact keys; all strings in French; be concrete and consultant-grade; cite the client's decoded answers, silosInformation and painPoints; never reuse generic filler):
{
"observe": [7 integers 1-5],
"synthesis": [2 or 3 justified paragraphs: describe the activity from effectif/nbrLaboratoires/typologieOffres; state the maturity level in WORDS only (no invented percentage); surface 2-3 major findings],
"findings": [3 short finding sentences],
"reco_line": "one recommendation sentence pointing to the roadmap",
"context_intro": "one intro paragraph for the context section",
"dash_reading": "one paragraph reading the biggest declared-vs-observed gaps",
"processes": [ 7 objects in the fixed order, each: {"pratique":"one justified paragraph of observed practice","forts":"one sentence","faibles":"one sentence","reco":"one concrete recommendation sentence","gain":"one short expected-gain phrase for the roadmap","priority":"optional enum"} ],
"transversal": [2 or 3 paragraphs from silosInformation + painPoints + the pattern of low scores],
"vision": [1 or 2 paragraphs],
"marche": [1 or 2 paragraphs]
}
Output ONLY this JSON object now. No code. No fences. No text before or after.
DIAGNOSTIC JSON:
<<<DIAGNOSTIC_JSON>>>`;

export type ReportState = 'idle' | 'gemini' | 'printing' | 'success' | 'failed';

interface ReportGeneratorProps {
  diagnosticJson: string;
  diagnosticId?: string | null;
  onBack?: () => void;
  onSuccess?: (url: string, filename: string, sizeKb: number) => void;
}

export function ReportGenerator({ diagnosticJson, diagnosticId, onBack, onSuccess }: ReportGeneratorProps) {
  const [runState, setRunState] = useState<ReportState>('idle');
  const [elapsedMs, setElapsedMs] = useState(0);
  const [errorResult, setErrorResult] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadSizeKb, setDownloadSizeKb] = useState<number | null>(null);
  const [downloadFilename, setDownloadFilename] = useState('');
  const [statusMessage, setStatusMessage] = useState('');

  // Auto-start generation on mount
  useEffect(() => {
    if (diagnosticJson) {
      handleGenerate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Cleanup blob URL on unmount
  useEffect(() => {
    return () => {
      if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    };
  }, [downloadUrl]);

  const callGemini = async (diagnosticJsonStr: string): Promise<string> => {
    const res = await fetch('/api/generate-report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        diagnosticJson: diagnosticJsonStr,
        promptTemplate: GEMINI_CONTENT_PROMPT
      }),
      signal: AbortSignal.timeout(120000),
    });

    if (!res.ok) {
      let errStr = `Gemini HTTP ${res.status}`;
      try {
        const errJson = await res.json();
        errStr = errJson.error || 'Unknown error';
      } catch (_) {}
      throw new Error(errStr);
    }

    const data = await res.json();
    return data.text || '';
  };

  const triggerDownload = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => document.body.removeChild(a), 200);
  };

  const handleGenerate = async () => {
    if (downloadUrl) {
      URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
    }
    setErrorResult(null);
    setRunState('gemini');
    setElapsedMs(0);
    setStatusMessage('Rédaction du contenu par IA…');

    const startTime = Date.now();
    const timer = setInterval(() => setElapsedMs(Date.now() - startTime), 100);

    try {
      const rawText = await callGemini(diagnosticJson);

      const firstCurly = rawText.indexOf('{');
      const lastCurly = rawText.lastIndexOf('}');
      if (firstCurly === -1 || lastCurly < firstCurly) {
        throw new Error("Gemini n'a pas renvoyé un JSON de contenu valide.");
      }
      
      let content: any;
      try {
        content = JSON.parse(rawText.substring(firstCurly, lastCurly + 1));
      } catch (e) {
        throw new Error("Impossible de parser le JSON de Gemini.");
      }

      if (!Array.isArray(content.observe) || !Array.isArray(content.processes)) {
        throw new Error('Structure de contenu Gemini invalide (observe/processes manquants).');
      }

      // 🛡️ CRITICAL SANITIZATION 1: Force 'observe' to be exactly 7 valid integers (1-5)
      let safeObserve: number[] = [];
      if (Array.isArray(content.observe)) {
        safeObserve = content.observe.map((val: any) => {
          const num = parseInt(String(val).trim(), 10);
          const safeNum = isNaN(num) ? 3 : num;
          return Math.min(5, Math.max(1, safeNum));
        });
      }
      while (safeObserve.length < 7) {
        safeObserve.push(3);
      }
      content.observe = safeObserve.slice(0, 7);

      // 🛡️ CRITICAL SANITIZATION 2: Prevent Python backend `int('')` crashes on user data
      const diag = JSON.parse(diagnosticJson);
      if (diag.digitalisation && typeof diag.digitalisation === 'object') {
        for (const key of Object.keys(diag.digitalisation)) {
          if (diag.digitalisation[key] === '' || diag.digitalisation[key] === null || diag.digitalisation[key] === undefined) {
            diag.digitalisation[key] = '1'; // Default to '1' (Manuel) instead of empty string
          }
        }
      }
      // Fallback for other potentially empty numeric fields
      if (diag.effectif === '') diag.effectif = '1-5';
      if (diag.nbrLaboratoires === '') diag.nbrLaboratoires = '1';

      setRunState('printing');
      setStatusMessage('Génération du document PDF sur le serveur…');

      const printerRes = await fetch(`${PRINTER}/generate_from_content`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ diagnostic: diag, content, format: 'pdf' }),
        signal: AbortSignal.timeout(180000),
      });

      if (!printerRes.ok) {
        let errStr = `Serveur HTTP ${printerRes.status}`;
        try {
          const errJson = await printerRes.json();
          errStr = `Serveur: ${errJson.error || 'Unknown'}\n${errJson.stderr || ''}`;
        } catch (_) {}
        throw new Error(errStr);
      }

      const blob = await printerRes.blob();
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      const sizeKb = blob.size / 1024;
      setDownloadSizeKb(sizeKb);

      const sanitize = (n: string) =>
        n.replace(/[^a-zA-Z0-9àâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ\s-]/g, '_');
      const dlName = `Rapport_Diagnostic_${sanitize(diag.raisonSociale || 'client')}.pdf`;

      // Upload to Supabase Storage if diagnosticId is provided
      let publicUrl = url;
      if (diagnosticId) {
        setStatusMessage('Sauvegarde du rapport dans le cloud...');
        const filePath = `${diagnosticId}/${dlName}`;
        const { error: uploadError } = await supabase.storage
          .from('reports')
          .upload(filePath, blob, { upsert: true, contentType: 'application/pdf' });
          
        if (!uploadError) {
          const { data: publicData } = supabase.storage.from('reports').getPublicUrl(filePath);
          publicUrl = publicData.publicUrl;
          
          await supabase
            .from('diagnostics')
            .update({
              status: 'report_generated',
              report_url: publicUrl,
              report_filename: dlName,
              report_size_kb: sizeKb
            })
            .eq('id', diagnosticId);
        } else {
          console.error("Failed to upload report to Supabase:", uploadError);
          await supabase
            .from('diagnostics')
            .update({
              status: 'report_generated',
              report_url: publicUrl,
              report_filename: dlName,
              report_size_kb: sizeKb
            })
            .eq('id', diagnosticId);
        }
      }

      setDownloadFilename(dlName);
      setStatusMessage('');
      setRunState('success');
      if (onSuccess) onSuccess(publicUrl, dlName, sizeKb);

      // Auto-download
      triggerDownload(url, dlName);
    } catch (err: any) {
      setRunState('failed');
      setStatusMessage('');
      let msg = err.message || String(err);
      if (
        msg.toLowerCase().includes('timeout') ||
        msg.toLowerCase().includes('fetch') ||
        msg.toLowerCase().includes('network')
      ) {
        msg += '\n\nLe serveur est peut-être en veille — réessayez une fois, le second appel est rapide.';
      }
      setErrorResult(msg);
    } finally {
      clearInterval(timer);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-6 font-sans">
      <div className="w-full max-w-lg">

        {onBack && runState !== 'gemini' && runState !== 'printing' && (
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-800 mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour au diagnostic
          </button>
        )}

        <div className="bg-white rounded-3xl border border-slate-100 shadow-[0_20px_50px_rgba(15,118,110,0.04)] p-8 md:p-10">

          {/* Loading */}
          {(runState === 'gemini' || runState === 'printing') && (
            <div className="flex flex-col items-center text-center gap-5 py-8">
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-4 border-slate-100" />
                <div className="absolute inset-0 w-16 h-16 rounded-full border-4 border-transparent border-t-slate-900 animate-spin" />
              </div>
              <div>
                <p className="text-base font-bold text-slate-800">{statusMessage}</p>
                <p className="text-sm text-slate-400 mt-1 font-mono">
                  {(elapsedMs / 1000).toFixed(1)}s
                </p>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div
                  className="h-full bg-slate-900 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: runState === 'gemini' ? '40%' : '75%' }}
                />
              </div>
            </div>
          )}

          {/* Success */}
          {runState === 'success' && downloadUrl && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center text-center gap-5 py-6"
            >
              <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7 text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Rapport généré ✓</h3>
                <p className="text-sm text-slate-400 mt-1">
                  {downloadFilename} · {downloadSizeKb?.toFixed(0)} Ko · {(elapsedMs / 1000).toFixed(1)}s
                </p>
              </div>

              <div className="flex flex-col items-center gap-3 w-full max-w-sm mt-2">
                <button
                  onClick={() => triggerDownload(downloadUrl!, downloadFilename)}
                  className="w-full inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-6 py-3.5 rounded-xl font-bold text-sm hover:bg-slate-800 active:scale-[0.98] transition-all shadow-md cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  Télécharger le PDF
                </button>

                <a
                  href={downloadUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 bg-slate-100 text-slate-800 px-6 py-3 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  Ouvrir dans un nouvel onglet
                </a>
              </div>

              <button
                onClick={handleGenerate}
                className="text-xs font-semibold text-slate-400 hover:text-slate-600 underline underline-offset-2 transition-colors"
              >
                Régénérer
              </button>
            </motion.div>
          )}

          {/* Error */}
          {runState === 'failed' && errorResult && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col gap-4 py-4"
            >
              <div className="flex items-start gap-3 bg-red-50 border border-red-100 rounded-2xl p-4">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-bold text-red-900">Échec de la génération</p>
                  <pre className="text-xs text-red-700 mt-2 whitespace-pre-wrap font-mono leading-relaxed max-h-40 overflow-auto">
                    {errorResult}
                  </pre>
                </div>
              </div>
              <button
                onClick={handleGenerate}
                className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all"
              >
                Réessayer
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}