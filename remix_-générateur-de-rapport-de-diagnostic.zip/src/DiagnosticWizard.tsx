// DiagnosticWizard.tsx
import React, { useState } from 'react';
import {
  ChevronRight,
  ChevronLeft,
  Check,
  Building,
  Users,
  Activity,
  Truck,
  Cpu,
  DollarSign,
  AlertCircle
} from 'lucide-react';

interface DiagnosticWizardProps {
  companyInfo?: {
    company_name?: string;
    ice?: string;
    email?: string;
    phone?: string;
  };
  initialData?: any;
  initialStep?: number;
  onClose?: () => void;
  onComplete: (data: any) => void;
  onSaveDraft?: (data: any, step: number) => Promise<void>;
  inline?: boolean;
}

export function DiagnosticWizard({
  companyInfo,
  initialData,
  initialStep,
  onClose,
  onComplete,
  onSaveDraft,
  inline
}: DiagnosticWizardProps) {
  const [step, setStep] = useState(initialStep || 1);
  const [formData, setFormData] = useState(() => {
    if (initialData) {
      return {
        raisonSociale: initialData.raisonSociale ?? companyInfo?.company_name ?? '',
        nomDirigeant: initialData.nomDirigeant ?? '',
        phoneEmail: initialData.phoneEmail ?? companyInfo?.phone ?? companyInfo?.email ?? '',
        effectif: initialData.effectif ?? '',
        nbrLaboratoires: initialData.nbrLaboratoires ?? '',
        nbrLaboratoiresDetail: initialData.nbrLaboratoiresDetail ?? '',
        typologieOffres: initialData.typologieOffres ?? [],
        chiffrageMethode: initialData.chiffrageMethode ?? [],
        difficultesClosing: initialData.difficultesClosing ?? '',
        suiviAvancement: initialData.suiviAvancement ?? [],
        gestionImprevus: initialData.gestionImprevus ?? [],
        evaluationSucces: initialData.evaluationSucces ?? [],
        planificationExtras: initialData.planificationExtras ?? [],
        adequationLogistique: initialData.adequationLogistique ?? '',
        digitalisation: {
          crm: initialData.digitalisation?.crm ?? '',
          chiffrage: initialData.digitalisation?.chiffrage ?? '',
          recettes: initialData.digitalisation?.recettes ?? '',
          personnel: initialData.digitalisation?.personnel ?? '',
          stocks: initialData.digitalisation?.stocks ?? '',
          flotte: initialData.digitalisation?.flotte ?? '',
          facturation: initialData.digitalisation?.facturation ?? ''
        },
        silosInformation: initialData.silosInformation ?? '',
        clotureFinanciere: initialData.clotureFinanciere ?? [],
        painPoint1: initialData.painPoint1 ?? '',
        painPoint2: initialData.painPoint2 ?? '',
        painPoint3: initialData.painPoint3 ?? ''
      };
    }
    return {
      raisonSociale: companyInfo?.company_name || '',
      nomDirigeant: '',
      phoneEmail: companyInfo?.phone || companyInfo?.email || '',
      effectif: '',
      nbrLaboratoires: '',
      nbrLaboratoiresDetail: '',
      typologieOffres: [] as string[],
      chiffrageMethode: [] as string[],
      difficultesClosing: '',
      suiviAvancement: [] as string[],
      gestionImprevus: [] as string[],
      evaluationSucces: [] as string[],
      planificationExtras: [] as string[],
      adequationLogistique: '',
      digitalisation: {
        crm: '',
        chiffrage: '',
        recettes: '',
        personnel: '',
        stocks: '',
        flotte: '',
        facturation: ''
      } as Record<string, string>,
      silosInformation: '',
      clotureFinanciere: [] as string[],
      painPoint1: '',
      painPoint2: '',
      painPoint3: ''
    };
  });

  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [showValidationError, setShowValidationError] = useState(false);

  const getCompletionDetails = () => {
    const fields = [
      { id: 'raisonSociale', name: 'Raison Sociale', step: 1, isAnswered: !!formData.raisonSociale?.trim() },
      { id: 'nomDirigeant', name: 'Nom du Dirigeant', step: 1, isAnswered: !!formData.nomDirigeant?.trim() },
      { id: 'phoneEmail', name: 'Contact', step: 1, isAnswered: !!formData.phoneEmail?.trim() },
      { id: 'effectif', name: 'Effectif', step: 2, isAnswered: !!formData.effectif },
      { id: 'nbrLaboratoires', name: 'Laboratoires', step: 2, isAnswered: !!formData.nbrLaboratoires },
      { id: 'typologieOffres', name: 'Typologie offres', step: 3, isAnswered: formData.typologieOffres?.length > 0 },
      { id: 'chiffrageMethode', name: 'Méthode chiffrage', step: 4, isAnswered: formData.chiffrageMethode?.length > 0 },
      { id: 'difficultesClosing', name: 'Difficultés closing', step: 5, isAnswered: !!formData.difficultesClosing?.trim() },
      { id: 'suiviAvancement', name: 'Suivi avancement', step: 6, isAnswered: formData.suiviAvancement?.length > 0 },
      { id: 'gestionImprevus', name: 'Gestion imprévus', step: 7, isAnswered: formData.gestionImprevus?.length > 0 },
      { id: 'evaluationSucces', name: 'Évaluation succès', step: 8, isAnswered: formData.evaluationSucces?.length > 0 },
      { id: 'planificationExtras', name: 'Planification extras', step: 8, isAnswered: formData.planificationExtras?.length > 0 },
      { id: 'adequationLogistique', name: 'Logistique', step: 9, isAnswered: !!formData.adequationLogistique?.trim() },
      { id: 'digitalisation_crm', name: 'Digitalisation CRM', step: 10, isAnswered: !!formData.digitalisation?.crm },
      { id: 'digitalisation_chiffrage', name: 'Digitalisation chiffrage', step: 10, isAnswered: !!formData.digitalisation?.chiffrage },
      { id: 'digitalisation_recettes', name: 'Digitalisation recettes', step: 10, isAnswered: !!formData.digitalisation?.recettes },
      { id: 'digitalisation_personnel', name: 'Digitalisation personnel', step: 10, isAnswered: !!formData.digitalisation?.personnel },
      { id: 'digitalisation_stocks', name: 'Digitalisation stocks', step: 10, isAnswered: !!formData.digitalisation?.stocks },
      { id: 'digitalisation_flotte', name: 'Digitalisation flotte', step: 10, isAnswered: !!formData.digitalisation?.flotte },
      { id: 'digitalisation_facturation', name: 'Digitalisation facturation', step: 10, isAnswered: !!formData.digitalisation?.facturation },
      { id: 'silosInformation', name: 'Silos information', step: 11, isAnswered: !!formData.silosInformation?.trim() },
      { id: 'clotureFinanciere', name: 'Clôture financière', step: 12, isAnswered: formData.clotureFinanciere?.length > 0 },
      { id: 'painPoint1', name: 'Point douleur 1', step: 13, isAnswered: !!formData.painPoint1?.trim() },
      { id: 'painPoint2', name: 'Point douleur 2', step: 13, isAnswered: !!formData.painPoint2?.trim() },
      { id: 'painPoint3', name: 'Point douleur 3', step: 13, isAnswered: !!formData.painPoint3?.trim() }
    ];

    const total = fields.length;
    const answered = fields.filter(f => f.isAnswered).length;
    const percentage = Math.round((answered / total) * 100);
    const missing = fields.filter(f => !f.isAnswered);

    return { total, answered, percentage, missing };
  };

  const steps = [
    { id: 1, title: 'Identité', icon: Building },
    { id: 2, title: 'Structure', icon: Building },
    { id: 3, title: 'Offres', icon: Activity },
    { id: 4, title: 'Chiffrage', icon: DollarSign },
    { id: 5, title: 'Closing', icon: DollarSign },
    { id: 6, title: 'Suivi', icon: Users },
    { id: 7, title: 'Imprévus', icon: Users },
    { id: 8, title: 'Évaluation', icon: Users },
    { id: 9, title: 'Logistique', icon: Truck },
    { id: 10, title: 'Digital', icon: Cpu },
    { id: 11, title: 'Silos', icon: Cpu },
    { id: 12, title: 'Finances', icon: DollarSign },
    { id: 13, title: 'Pain Points', icon: AlertCircle }
  ];

  const triggerDraftSave = async (data: any, stepNum: number) => {
    if (!onSaveDraft) return;
    setSaveStatus('saving');
    try {
      await onSaveDraft(data, stepNum);
      setSaveStatus('saved');
      setLastSaved(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Error saving diagnostic draft:', err);
      setSaveStatus('error');
    }
  };

  const handleInputChange = (field: string, value: any) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    if (showValidationError) setShowValidationError(false);
  };

  const toggleArrayItem = (
    field: 'typologieOffres' | 'chiffrageMethode' | 'suiviAvancement' | 'gestionImprevus' | 'evaluationSucces' | 'planificationExtras' | 'clotureFinanciere',
    value: string
  ) => {
    setFormData(prev => {
      const current = prev[field] as string[];
      const updatedArray = current.includes(value) ? current.filter(item => item !== value) : [...current, value];
      return { ...prev, [field]: updatedArray };
    });
    if (showValidationError) setShowValidationError(false);
  };

  const handleDigitalisationChange = (processKey: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      digitalisation: { ...prev.digitalisation, [processKey]: value }
    }));
    if (showValidationError) setShowValidationError(false);
  };

  const handleNext = async () => {
    if (step < 13) {
      const nextStep = step + 1;
      setStep(nextStep);
      const el = document.getElementById('diagnostic-container');
      if (el) el.scrollTop = 0;
      await triggerDraftSave(formData, nextStep);
    } else {
      const { percentage } = getCompletionDetails();
      if (percentage < 80) {
        setShowValidationError(true);
        setTimeout(() => {
          const el = document.getElementById('diagnostic-container');
          if (el) el.scrollTop = el.scrollHeight;
        }, 100);
        return;
      }
      setShowValidationError(false);
      onComplete(formData);
    }
  };

  const handlePrev = async () => {
    if (showValidationError) setShowValidationError(false);
    if (step > 1) {
      const prevStep = step - 1;
      setStep(prevStep);
      const el = document.getElementById('diagnostic-container');
      if (el) el.scrollTop = 0;
      await triggerDraftSave(formData, prevStep);
    }
  };

  return (
    <div
      className={
        inline
          ? 'flex flex-col font-sans overflow-hidden w-full'
          : 'fixed inset-0 bg-[#f8fafc] z-50 flex flex-col animate-in fade-in duration-200 font-sans'
      }
    >
      <div
        id="diagnostic-container"
        className={inline ? 'w-full flex flex-col font-sans' : 'bg-[#f8fafc] w-full h-full flex flex-col overflow-hidden font-sans'}
      >
        {/* Header */}
        <div className="bg-transparent border-b border-slate-100 py-5 relative flex flex-col sm:flex-row justify-center items-center gap-4 shrink-0">
          <div className="text-center">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Diagnostic+</h2>
          </div>
          {!inline && onClose && (
            <div className="absolute right-4 sm:right-6 top-1/2 -translate-y-1/2">
              <button
                onClick={onClose}
                className="text-slate-500 hover:text-slate-900 font-semibold text-sm transition-colors bg-transparent border-none py-1.5 px-0 cursor-pointer"
              >
                Quitter
              </button>
            </div>
          )}
        </div>

        {/* Progress Indicator - Scrollable on mobile */}
        <div className="bg-transparent border-b border-slate-100 py-3 flex justify-center shrink-0 overflow-x-auto">
          <div className="flex items-center gap-2 px-4">
            {steps.map((s, index) => {
              const isCompleted = step > s.id;
              const isActive = step === s.id;
              return (
                <React.Fragment key={s.id}>
                  <button
                    onClick={async () => {
                      if (showValidationError) setShowValidationError(false);
                      setStep(s.id);
                      const el = document.getElementById('diagnostic-container');
                      if (el) el.scrollTop = 0;
                      await triggerDraftSave(formData, s.id);
                    }}
                    className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-[10px] sm:text-xs transition-all shrink-0 cursor-pointer border-none p-0 focus:outline-none ${
                      isCompleted || isActive ? 'bg-slate-900 text-white shadow-sm' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {isCompleted ? <Check className="w-3 h-3 sm:w-4 sm:h-4 stroke-[3]" /> : s.id}
                  </button>
                  {index < steps.length - 1 && (
                    <div className="flex-1 h-[2px] rounded-full bg-slate-100 overflow-hidden min-w-[20px] sm:min-w-[30px]">
                      <div className="h-full bg-slate-900 transition-all duration-300" style={{ width: isCompleted ? '100%' : '0%' }} />
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-10 bg-[#f8fafc]">
          <div className="max-w-3xl mx-auto bg-white rounded-[24px] sm:rounded-[32px] p-6 sm:p-8 md:p-12 border border-slate-100/80 shadow-[0_20px_50px_rgba(15,118,110,0.03)]">

            {/* Step 1: Identité */}
            {step === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  1. Identité de l'entreprise
                </h3>
                <div className="space-y-4">
                  <label className="block">
                    <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Raison Sociale</span>
                    <input
                      type="text"
                      value={formData.raisonSociale}
                      onChange={(e) => handleInputChange('raisonSociale', e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm font-medium text-slate-800"
                      placeholder="Ex: Saveurs de l'Atlas"
                    />
                  </label>
                  <label className="block">
                    <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Nom du Dirigeant</span>
                    <input
                      type="text"
                      value={formData.nomDirigeant}
                      onChange={(e) => handleInputChange('nomDirigeant', e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm font-medium text-slate-800"
                      placeholder="Ex: M. Rachid El Idrissi"
                    />
                  </label>
                  <label className="block">
                    <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Téléphone & Email</span>
                    <input
                      type="text"
                      value={formData.phoneEmail}
                      onChange={(e) => handleInputChange('phoneEmail', e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm font-medium text-slate-800"
                      placeholder="+212 600000000 • contact@entreprise.ma"
                    />
                  </label>
                </div>
              </div>
            )}

            {/* Step 2: Structure */}
            {step === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  2. Structure de l'entreprise
                </h3>
                <div className="space-y-4">
                  <div>
                    <span className="block mb-3 text-xs text-slate-400 uppercase tracking-wider font-semibold">Effectif Permanent</span>
                    <div className="grid grid-cols-2 gap-3">
                      {['1-5', '6-15', '16-50', '50+'].map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => handleInputChange('effectif', item)}
                          className={`p-3 text-center text-sm font-semibold rounded-xl border-2 transition-all ${
                            formData.effectif === item ? 'border-[#0f172a] bg-[#f8fafc] text-[#1e293b]' : 'border-slate-100 bg-white text-slate-600'
                          }`}
                        >
                          {item === '50+' ? '+50 pers.' : `${item} pers.`}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="block mb-3 text-xs text-slate-400 uppercase tracking-wider font-semibold">Nombre de Laboratoires</span>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => { handleInputChange('nbrLaboratoires', '1'); handleInputChange('nbrLaboratoiresDetail', ''); }}
                        className={`p-4 text-left rounded-xl border-2 transition-all ${
                          formData.nbrLaboratoires === '1' ? 'border-[#0f172a] bg-[#f8fafc]' : 'border-slate-100 bg-white'
                        }`}
                      >
                        <span className="block font-bold text-sm">1 site</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleInputChange('nbrLaboratoires', 'multi')}
                        className={`p-4 text-left rounded-xl border-2 transition-all ${
                          formData.nbrLaboratoires === 'multi' ? 'border-[#0f172a] bg-[#f8fafc]' : 'border-slate-100 bg-white'
                        }`}
                      >
                        <span className="block font-bold text-sm">Multi-sites</span>
                      </button>
                    </div>
                    {formData.nbrLaboratoires === 'multi' && (
                      <input
                        type="text"
                        value={formData.nbrLaboratoiresDetail}
                        onChange={(e) => handleInputChange('nbrLaboratoiresDetail', e.target.value)}
                        placeholder="Précisez le nombre et localisation"
                        className="w-full border border-slate-200 rounded-xl p-3 mt-3 text-sm"
                      />
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Typologie des offres */}
            {step === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  3. Typologie des offres
                </h3>
                <p className="text-sm text-slate-500">Plusieurs choix possibles</p>
                <div className="space-y-2">
                  {[
                    { id: 'standard', label: 'Formules clés en main', desc: 'Package fixe par personne' },
                    { id: 'sur-mesure', label: 'Devis 100% sur-mesure', desc: 'Reconstruit à partir de zéro' },
                    { id: 'modulaire', label: 'Prestations modulaires', desc: 'Traiteur + matériel + service' }
                  ].map((item) => (
                    <label
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        formData.typologieOffres.includes(item.id) ? 'border-[#0f172a]/30 bg-[#f8fafc]' : 'border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                        <input type="checkbox" checked={formData.typologieOffres.includes(item.id)} onChange={() => toggleArrayItem('typologieOffres', item.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${formData.typologieOffres.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                          {formData.typologieOffres.includes(item.id) && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <div>
                        <span className="block text-sm font-bold">{item.label}</span>
                        <span className="block text-xs text-slate-400 mt-1">{item.desc}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Step 4: Méthode de chiffrage */}
            {step === 4 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  4. Méthode de chiffrage
                </h3>
                <p className="text-sm text-slate-500">Plusieurs choix possibles</p>
                <div className="space-y-2">
                  {[
                    { id: 'manuel', label: 'Calcul manuel + coefficient global' },
                    { id: 'excel_lent', label: 'Recalcul complet sur Excel à chaque modification' },
                    { id: 'remises_aveugles', label: 'Remises globales sans visibilité marge nette' }
                  ].map((item) => (
                    <label
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        formData.chiffrageMethode.includes(item.id) ? 'border-[#0f172a]/30 bg-[#f8fafc]' : 'border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                        <input type="checkbox" checked={formData.chiffrageMethode.includes(item.id)} onChange={() => toggleArrayItem('chiffrageMethode', item.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${formData.chiffrageMethode.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                          {formData.chiffrageMethode.includes(item.id) && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Step 5: Difficultés closing */}
            {step === 5 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  5. Difficultés de closing
                </h3>
                <label className="block">
                  <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Vos principales difficultés</span>
                  <textarea
                    value={formData.difficultesClosing}
                    onChange={(e) => handleInputChange('difficultesClosing', e.target.value)}
                    rows={4}
                    placeholder="Ex: Lenteur de mise à jour des devis, négociations de dernière minute..."
                    className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm leading-relaxed"
                  />
                </label>
              </div>
            )}

            {/* Step 6: Suivi avancement */}
            {step === 6 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  6. Suivi de l'avancement
                </h3>
                <div className="space-y-2">
                  {[
                    { id: 'jalons', label: "Jalons manuels (validation menu, acompte...)" },
                    { id: 'memoire', label: 'Suivi sur la mémoire du chef de projet' },
                    { id: 'kanban_deconnecte', label: 'Outil collaboratif déconnecté (Trello, Asana)' }
                  ].map((item) => (
                    <label
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        formData.suiviAvancement.includes(item.id) ? 'border-[#0f172a]/30 bg-[#f8fafc]' : 'border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                        <input type="checkbox" checked={formData.suiviAvancement.includes(item.id)} onChange={() => toggleArrayItem('suiviAvancement', item.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${formData.suiviAvancement.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                          {formData.suiviAvancement.includes(item.id) && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Step 7: Gestion imprévus */}
            {step === 7 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  7. Gestion des imprévus
                </h3>
                <div className="space-y-2">
                  {[
                    { id: 'verbal', label: "Transmission verbale ou note écrite (risque d'oubli)" },
                    { id: 'reedition', label: 'Réédition papier et redistribution manuelle' },
                    { id: 'centralise', label: 'Système centralisé temps réel' }
                  ].map((item) => (
                    <label
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        formData.gestionImprevus.includes(item.id) ? 'border-[#0f172a]/30 bg-[#f8fafc]' : 'border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                        <input type="checkbox" checked={formData.gestionImprevus.includes(item.id)} onChange={() => toggleArrayItem('gestionImprevus', item.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${formData.gestionImprevus.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                          {formData.gestionImprevus.includes(item.id) && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Step 8: Évaluation & Planification */}
            {step === 8 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  8. Évaluation & Planification
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <span className="block mb-2 text-xs text-slate-400 uppercase tracking-wider font-semibold">Évaluation du succès</span>
                    <div className="space-y-2">
                      {[
                        { id: 'verbal_client', label: 'Retours verbaux client' },
                        { id: 'debriefing', label: 'Débriefing formalisé des écarts' },
                        { id: 'pas_de_suivi', label: 'Pas de suivi post-événement' }
                      ].map((item) => (
                        <label key={item.id} className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer ${formData.evaluationSucces.includes(item.id) ? 'border-[#0f172a] bg-[#f8fafc]' : 'border-slate-100'}`}>
                          <input type="checkbox" checked={formData.evaluationSucces.includes(item.id)} onChange={() => toggleArrayItem('evaluationSucces', item.id)} className="sr-only" />
                          <div className={`w-5 h-5 rounded-md flex items-center justify-center ${formData.evaluationSucces.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                            {formData.evaluationSucces.includes(item.id) && <Check className="w-3 h-3" />}
                          </div>
                          <span className="text-sm">{item.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="block mb-2 text-xs text-slate-400 uppercase tracking-wider font-semibold">Planification des extras</span>
                    <div className="space-y-2">
                      {[
                        { id: 'sms_whatsapp', label: 'SMS/WhatsApp + planning Excel' },
                        { id: 'interim_externe', label: 'Agences d\'intérim externes' },
                        { id: 'dysfonctionnements', label: 'Dysfonctionnements fréquents' }
                      ].map((item) => (
                        <label key={item.id} className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer ${formData.planificationExtras.includes(item.id) ? 'border-[#0f172a] bg-[#f8fafc]' : 'border-slate-100'}`}>
                          <input type="checkbox" checked={formData.planificationExtras.includes(item.id)} onChange={() => toggleArrayItem('planificationExtras', item.id)} className="sr-only" />
                          <div className={`w-5 h-5 rounded-md flex items-center justify-center ${formData.planificationExtras.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                            {formData.planificationExtras.includes(item.id) && <Check className="w-3 h-3" />}
                          </div>
                          <span className="text-sm">{item.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 9: Logistique */}
            {step === 9 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  9. Adéquation logistique
                </h3>
                <label className="block">
                  <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Gestion du matériel et vaisselle</span>
                  <textarea
                    value={formData.adequationLogistique}
                    onChange={(e) => handleInputChange('adequationLogistique', e.target.value)}
                    rows={4}
                    placeholder="Ex: Comptages physiques, double-réservations, location dernière minute..."
                    className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm leading-relaxed"
                  />
                </label>
              </div>
            )}

            {/* Step 10: Digitalisation */}
            {step === 10 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  10. Maturité digitale
                </h3>
                <div className="overflow-x-auto border border-slate-100 rounded-xl">
                  <table className="w-full text-left border-collapse min-w-[600px]">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-100">
                        <th className="p-3 text-[10px] font-bold text-slate-500 uppercase">Processus</th>
                        {['1. Manuel', '2. Excel', '3. Logiciel', '4. ERP'].map((h) => (
                          <th key={h} className="p-3 text-[9px] font-bold text-slate-400 text-center">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {[
                        { key: 'crm', label: 'CRM & Devis' },
                        { key: 'chiffrage', label: "Chiffrage ingrédients" },
                        { key: 'recettes', label: 'Fiches techniques' },
                        { key: 'personnel', label: 'Planification extras' },
                        { key: 'stocks', label: 'Gestion stocks' },
                        { key: 'flotte', label: 'Flotte véhicules' },
                        { key: 'facturation', label: 'Facturation' }
                      ].map((proc) => (
                        <tr key={proc.key}>
                          <td className="p-3 text-xs font-semibold">{proc.label}</td>
                          {['1', '2', '3', '4'].map((val) => (
                            <td key={val} className="p-3 text-center">
                              <button
                                type="button"
                                onClick={() => handleDigitalisationChange(proc.key, val)}
                                className={`w-6 h-6 mx-auto rounded-full border-2 flex items-center justify-center ${
                                  formData.digitalisation[proc.key] === val ? 'border-[#0f172a] bg-[#0f172a] text-white shadow-md' : 'border-slate-300 hover:border-slate-400 bg-white shadow-sm transition-all'
                                }`}
                              >
                                {formData.digitalisation[proc.key] === val && <div className="w-2 h-2 rounded-full bg-white" />}
                              </button>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Step 11: Silos information */}
            {step === 11 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  11. Silos d'information
                </h3>
                <label className="block">
                  <span className="block mb-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">Principaux îlots générant pertes de temps</span>
                  <textarea
                    value={formData.silosInformation}
                    onChange={(e) => handleInputChange('silosInformation', e.target.value)}
                    rows={4}
                    placeholder="Ex: La cuisine ne reçoit pas les fiches techniques à temps..."
                    className="w-full border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f172a]/20 focus:border-[#0f172a] transition-all text-sm leading-relaxed"
                  />
                </label>
              </div>
            )}

            {/* Step 12: Clôture financière */}
            {step === 12 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  12. Clôture financière
                </h3>
                <div className="space-y-2">
                  {[
                    { id: 'scrupuleux', label: 'Formule (Produits - Charges) projet par projet sous 48h' },
                    { id: 'estimation_brute', label: 'Marge brute sur nourriture seulement' },
                    { id: 'impossible_automatisation', label: 'Calcul impossible à automatiser' }
                  ].map((item) => (
                    <label
                      key={item.id}
                      className={`flex items-start gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        formData.clotureFinanciere.includes(item.id) ? 'border-[#0f172a]/30 bg-[#f8fafc]' : 'border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="relative flex items-center justify-center shrink-0 mt-0.5">
                        <input type="checkbox" checked={formData.clotureFinanciere.includes(item.id)} onChange={() => toggleArrayItem('clotureFinanciere', item.id)} className="sr-only" />
                        <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${formData.clotureFinanciere.includes(item.id) ? 'bg-[#0f172a] text-white' : 'border-2 border-slate-200'}`}>
                          {formData.clotureFinanciere.includes(item.id) && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Step 13: Pain points */}
            {step === 13 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-bold text-slate-800 border-b border-slate-100 pb-2">
                  13. Points de douleur
                </h3>
                <div className="space-y-4">
                  {['painPoint1', 'painPoint2', 'painPoint3'].map((field, idx) => (
                    <div key={field} className="bg-slate-50 p-4 rounded-xl">
                      <span className="block text-[10px] font-bold text-slate-500 uppercase mb-2">Point de douleur {idx + 1}</span>
                      <input
                        type="text"
                        value={formData[field as keyof typeof formData]}
                        onChange={(e) => handleInputChange(field, e.target.value)}
                        placeholder={`Ex: ${idx === 0 ? 'Oublis logistiques' : idx === 1 ? 'Temps excessif sur Excel' : 'Imprécision calcul marge'}`}
                        className="w-full border border-slate-200 rounded-lg p-2.5 text-sm"
                      />
                    </div>
                  ))}
                </div>

                {showValidationError && (
                  <div className="mt-6 bg-red-50 border border-red-200 rounded-2xl p-5 space-y-3">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-bold text-red-950">Formulaire incomplet ({getCompletionDetails().percentage}%)</h4>
                        <p className="text-xs text-red-700 mt-1">
                          Répondez à au moins <strong>80% des questions</strong> pour soumettre.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 pl-8">
                      {getCompletionDetails().missing.slice(0, 5).map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => { setStep(item.step); setShowValidationError(false); }}
                          className="text-[10px] font-bold text-red-700 bg-white border border-red-200 px-2 py-1 rounded"
                        >
                          Étape {item.step}: {item.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>

        {/* Footer Navigation */}
        <div className="bg-white border-t border-slate-100 p-4 sm:p-6 flex justify-between items-center shrink-0">
          <button
            type="button"
            onClick={handlePrev}
            disabled={step === 1}
            className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl font-bold text-sm transition-all ${
              step === 1 ? 'text-slate-300 bg-slate-50 cursor-not-allowed' : 'text-slate-600 bg-slate-100 hover:bg-slate-200'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Précédent
          </button>
          <button
            type="button"
            onClick={handleNext}
            className="flex items-center gap-2 bg-[#0f172a] text-white hover:bg-[#1e293b] px-5 sm:px-6 py-2.5 sm:py-3 rounded-xl font-bold text-sm transition-all shadow-md"
          >
            {step === 13 ? 'Soumettre' : 'Suivant'}
            {step < 13 && <ChevronRight className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}