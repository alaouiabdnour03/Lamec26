import React, { useState } from 'react';
import { Check, Loader2 } from 'lucide-react';

interface ClientLoginProps {
  /** Called with the typed credentials. Throw to surface an error; resolve/navigate on success. */
  onSubmit?: (creds: { ice: string; code: string }) => void | Promise<void>;
  onBack?: () => void;
  logoUrl?: string;
  brandName?: string;
  eyebrow?: string;
  title?: string;
}

export function ClientLogin({
  onSubmit,
  onBack,
  logoUrl = 'https://storage.googleapis.com/tagjs-prod.appspot.com/v1/yG6rnZOno2/me08pjb3_expires_30_days.png',
  brandName = 'LA MEC CONSEILS',
  eyebrow = 'Espace Client Partenaire',
  title = 'Connexion sécurisée',
}: ClientLoginProps) {
  const [ice, setIce] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ice.trim() || !code.trim()) {
      setError('Veuillez saisir votre ICE et votre code d\'accès.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await onSubmit?.({ ice: ice.trim(), code: code.trim() });
    } catch (err: any) {
      setError(err?.message || 'Identifiants invalides');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="lk-root relative min-h-screen flex items-center justify-center p-6 w-full text-slate-800 font-sans">
      {/* scoped motion + ambient depth — nothing here changes the empty-state look */}
      <style>{`
        .lk-root { --lk-ink:#121314; --lk-ease:cubic-bezier(.4,0,.2,1); background:#f4f5f7; }
        /* layered ambient: a soft top light + a whisper of cool depth at the base */
        .lk-root::before, .lk-root::after { content:""; position:absolute; inset:-12%; z-index:0; pointer-events:none; }
        .lk-root::before { background:radial-gradient(120% 75% at 50% -8%, rgba(255,255,255,.95), rgba(255,255,255,0) 58%); animation:lk-drift 16s var(--lk-ease) infinite alternate; }
        .lk-root::after  { background:radial-gradient(90% 60% at 50% 116%, rgba(15,23,42,.05), rgba(15,23,42,0) 60%); }
        @keyframes lk-drift { from{ transform:translate3d(-1.2%,-1%,0); opacity:.85 } to{ transform:translate3d(1.2%,1%,0); opacity:1 } }
        .lk-root > * { position:relative; z-index:1; }

        /* staggered entrance — final frame == the screenshot */
        .lk-rise { animation:lk-rise .6s var(--lk-ease) both; }
        .lk-rise-2 { animation:lk-rise .6s var(--lk-ease) .12s both; }
        @keyframes lk-rise { from{ opacity:0; transform:translateY(14px) } to{ opacity:1; transform:translateY(0) } }

        /* logo settles in, then tilts on hover (matches the brand-chip behaviour elsewhere) */
        .lk-logo { transition:transform .35s var(--lk-ease); transform-origin:50% 60%; }
        .lk-brand:hover .lk-logo { transform:rotate(-6deg) scale(1.06); }

        /* inputs: the validity tick pops only when the field holds text */
        .lk-tick { transition:opacity .2s var(--lk-ease), transform .2s var(--lk-ease); }

        /* button: a light sheen sweeps across on hover; press depresses it */
        .lk-submit { position:relative; overflow:hidden; transition:transform .15s var(--lk-ease), background-color .2s var(--lk-ease), box-shadow .2s var(--lk-ease); }
        .lk-submit::before {
          content:""; position:absolute; top:0; left:0; width:60%; height:100%;
          background:linear-gradient(100deg, transparent, rgba(255,255,255,.18), transparent);
          transform:translateX(-160%); transition:transform .6s var(--lk-ease);
        }
        .lk-submit:hover::before { transform:translateX(260%); }
        .lk-submit:hover { box-shadow:0 10px 24px rgba(18,19,20,.22); }
        .lk-submit:active { transform:translateY(1px) scale(.992); }

        /* back link: an underline grows from the centre on hover (zero layout shift) */
        .lk-back { position:relative; }
        .lk-back::after {
          content:""; position:absolute; left:50%; bottom:-3px; height:1.5px; width:62%;
          background:currentColor; border-radius:2px; transform:translateX(-50%) scaleX(0);
          transform-origin:center; transition:transform .3s var(--lk-ease);
        }
        .lk-back:hover::after { transform:translateX(-50%) scaleX(1); }

        /* error: shakes in */
        .lk-shake { animation:lk-shake .4s var(--lk-ease); }
        @keyframes lk-shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-5px)} 40%{transform:translateX(5px)} 60%{transform:translateX(-3px)} 80%{transform:translateX(3px)} }

        @media (prefers-reduced-motion: reduce) {
          .lk-rise,.lk-rise-2,.lk-root::before,.lk-shake { animation:none !important; }
          .lk-submit::before { display:none; }
        }
      `}</style>

      <div className="w-full max-w-md space-y-6">
        {/* Brand lockup */}
        <div className="lk-brand lk-rise text-center cursor-default select-none">
          <img src={logoUrl} className="lk-logo w-14 h-10 object-contain mx-auto mb-3" alt="Logo" />
          <h1 className="text-xl font-extrabold tracking-tight text-slate-950">{brandName}</h1>
          <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-0.5">{eyebrow}</p>
        </div>

        {/* Card */}
        <form
          onSubmit={handleSubmit}
          className="lk-rise-2 bg-white p-8 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.01),0_20px_40px_rgba(0,0,0,0.04)] w-full border border-slate-200/50"
        >
          {error && (
            <p className="lk-shake bg-red-50 text-red-600 p-3 rounded-xl mb-4 text-xs font-semibold leading-relaxed border border-red-100">
              {error}
            </p>
          )}

          <div className="space-y-4 mb-6">
            {/* ICE */}
            <label className="block text-sm font-bold text-slate-700">
              <span className="block mb-1.5">Identifiant unique (ICE)</span>
              <div className="relative">
                <input
                  type="text"
                  value={ice}
                  onChange={(e) => { setIce(e.target.value); if (error) setError(''); }}
                  placeholder="Ex: 001234567890123"
                  autoComplete="username"
                  className="w-full border border-slate-200 rounded-xl pl-3 pr-10 py-3 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-all text-sm font-semibold"
                  required
                />
                <Check
                  className={`lk-tick pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500 ${
                    ice.trim() ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
                  }`}
                  strokeWidth={3}
                />
              </div>
            </label>

            {/* Code */}
            <label className="block text-sm font-bold text-slate-700">
              <span className="block mb-1.5">Code de dossier confidentiel</span>
              <div className="relative">
                <input
                  type="text"
                  value={code}
                  onChange={(e) => { setCode(e.target.value); if (error) setError(''); }}
                  placeholder="Ex: LMC-892A"
                  autoComplete="current-password"
                  className="w-full border border-slate-200 rounded-xl pl-3 pr-10 py-3 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-black/10 focus:border-black transition-all font-mono tracking-wider text-sm font-semibold"
                  required
                />
                <Check
                  className={`lk-tick pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500 ${
                    code.trim() ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
                  }`}
                  strokeWidth={3}
                />
              </div>
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="lk-submit w-full bg-[#121314] hover:bg-black disabled:opacity-70 text-white rounded-xl py-3.5 font-bold cursor-pointer text-sm uppercase tracking-wider flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            <span>{loading ? 'Vérification…' : 'Se connecter'}</span>
          </button>

          <button
            type="button"
            onClick={onBack}
            className="lk-back w-full mt-4 text-slate-400 hover:text-black text-xs font-extrabold transition-colors uppercase tracking-wider text-center cursor-pointer bg-transparent border-none"
          >
            Retour à l'accueil
          </button>
        </form>
      </div>
    </div>
  );
}
