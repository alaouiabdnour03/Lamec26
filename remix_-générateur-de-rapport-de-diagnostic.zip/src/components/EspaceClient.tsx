import React, { useState } from 'react';
import { 
  Building2,
  ArrowLeft, 
  Home, 
  Folder, 
  Users, 
  FileText, 
  Compass, 
  Check, 
  File,
  FolderLock,
  FolderOpen,
  Download,
  ExternalLink
} from 'lucide-react';
import { RoadmapStepper, type RoadmapStep } from './RoadmapStepper';
import { DiagnosticWizard } from '../DiagnosticWizard';
import { ReportGenerator } from '../ReportGenerator';
import { supabase, DiagnosticData } from '../lib/supabase';
import { useEffect } from 'react';

export interface Dossier {
  id: string;
  date: string;
  url?: string;
  filename?: string;
  sizeKb?: number;
}

export function EspaceClient({ onBack, data }: { onBack: () => void, data?: any }) {
  const displayData = data || {};
  
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [auditView, setAuditView] = useState<'list' | 'wizard' | 'generator' | 'viewer'>('list');
  const [pendingDiagnostic, setPendingDiagnostic] = useState<string | null>(null);
  const [dossiers, setDossiers] = useState<Dossier[]>([]);
  const [dbDiagnostics, setDbDiagnostics] = useState<DiagnosticData[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [activeDiagnosticId, setActiveDiagnosticId] = useState<string | null>(null);
  const [diagnosticInitialData, setDiagnosticInitialData] = useState<any>(undefined);
  const [diagnosticInitialStep, setDiagnosticInitialStep] = useState<number>(1);

  useEffect(() => {
    if (displayData.id) {
      loadDiagnostics();
    }
  }, [displayData.id]);

  const loadDiagnostics = async () => {
    setLoadingDocs(true);
    try {
      const { data: diags, error } = await supabase
        .from('diagnostics')
        .select('*')
        .eq('client_id', displayData.id)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setDbDiagnostics(diags || []);
      
      // Map to Dossier type for UI
      const mapped = (diags || []).map((d: any) => ({
        id: d.id.substring(0, 8).toUpperCase(),
        date: new Date(d.created_at).toLocaleString('fr-FR', {
          day: '2-digit', month: '2-digit', year: 'numeric',
          hour: '2-digit', minute: '2-digit'
        }),
        url: d.report_url,
        filename: d.report_filename,
        sizeKb: d.report_size_kb,
        rawId: d.id,
        status: d.status,
        step: d.current_step,
        data: d.data
      }));
      setDossiers(mapped);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingDocs(false);
    }
  };

  const diagnosticCompleted = true; 
  const quoteStatus: string = 'None'; 
  const letterOfEngagementSigned = false;
  const contractSigned = false;

  const roadmapSteps: RoadmapStep[] = [
    { 
      stepName: 'STEP 1', 
      title: 'Audit', 
      badge: diagnosticCompleted ? 'FAIT' : 'À FAIRE', 
      state: diagnosticCompleted ? 'done' : 'active',
      icon: <Check className="w-5 h-5" strokeWidth={3} />,
      onSelect: diagnosticCompleted ? () => setSelectedTab('audit') : undefined
    },
    { 
      stepName: 'STEP 2', 
      title: 'Devis', 
      badge: quoteStatus !== 'None' ? 'ACTIF' : 'À FAIRE',
      state: diagnosticCompleted ? (quoteStatus !== 'None' ? 'done' : 'active') : 'todo',
      icon: <File className="w-[22px] h-[22px]" strokeWidth={2} />,
      onSelect: diagnosticCompleted ? () => setSelectedTab('quote') : undefined
    },
    { 
      stepName: 'STEP 3', 
      title: 'Engagement', 
      badge: letterOfEngagementSigned ? 'FAIT' : 'À FAIRE',
      state: letterOfEngagementSigned ? 'done' : quoteStatus !== 'None' ? 'active' : 'todo',
      icon: <FileText className="w-[22px] h-[22px]" strokeWidth={2} />,
      onSelect: quoteStatus !== 'None' ? () => setSelectedTab('contracts') : undefined
    },
    { 
      stepName: 'STEP 4', 
      title: 'Mission', 
      badge: contractSigned ? 'EN COURS' : 'À FAIRE',
      state: contractSigned ? 'done' : letterOfEngagementSigned ? 'active' : 'todo',
      icon: <Compass className="w-[22px] h-[22px]" strokeWidth={2} />,
      onSelect: contractSigned ? () => setSelectedTab('project') : undefined
    }
  ];

  return (
    <div className="min-h-screen bg-[#F4F6F8] w-full font-sans text-slate-800 flex flex-col">
      {/* Header */}
      <header className="w-full bg-[#F4F6F8] px-4 md:px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-slate-200 shadow-sm">
            <Building2 className="w-5 h-5 text-slate-700" />
          </div>
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight text-slate-900 line-clamp-1">Espace Client Partenaire</h1>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-50 transition-colors"
          >
            Déconnexion
          </button>
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex flex-col xl:flex-row flex-1 px-4 md:px-8 pb-10 gap-6 xl:gap-8 max-w-[1600px] mx-auto w-full">
        
        {/* Sidebar */}
        <aside className="w-full xl:w-[300px] flex-shrink-0 flex flex-col gap-4 xl:gap-6">
          <div className="bg-white rounded-2xl p-3 border border-slate-200/50 shadow-[0_1px_3px_rgba(0,0,0,0.01),0_10px_30px_rgba(0,0,0,0.02)] space-y-1 overflow-hidden">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block px-3 mb-2.5">Navigation</span>

            <div className="flex xl:flex-col overflow-x-auto gap-2 pb-2 xl:pb-0 -mx-1 px-1 custom-scrollbar">
            {[
              { id: 'dashboard',     label: 'Tableau de bord',     icon: Home },
              { id: 'audit',         label: '1. Audit & Diagnostic', icon: Folder, badge: diagnosticCompleted ? 'Complété' : 'À faire' },
              { id: 'quote',         label: '2. Devis & Subventions', icon: Users, badge: quoteStatus !== 'None' ? (quoteStatus === 'Waiting for Grant Documents' ? 'En attente' : 'Actif') : undefined },
              { id: 'contracts',     label: '3. Rapports & Contrats', icon: FolderLock, disabled: !letterOfEngagementSigned },
              { id: 'project',       label: '4. Suivi de Projet',     icon: Compass,    disabled: !contractSigned },
              { id: 'documentation', label: '5. Bibliothèque de Docs', icon: FolderOpen }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = selectedTab === tab.id;
              const isDisabled = tab.disabled;
              return (
                <button
                  key={tab.id}
                  disabled={isDisabled}
                  onClick={() => setSelectedTab(tab.id as any)}
                  className={`min-w-fit xl:w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-all border-none gap-4 ${
                    isDisabled
                      ? 'opacity-35 cursor-not-allowed text-slate-300 bg-transparent'
                      : isActive
                      ? 'bg-[#121314] text-white font-semibold shadow-sm'
                      : 'text-slate-600 hover:bg-black/[0.03] hover:text-slate-900 cursor-pointer bg-transparent font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="relative flex items-center justify-center">
                      <Icon className={`w-4 h-4 stroke-[1.8] ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      {tab.badge && tab.badge !== 'Complété' && (
                        <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                      )}
                    </div>
                    <span>{tab.label}</span>
                  </div>
                  {tab.badge && (
                    <span className={`text-[11px] font-semibold ${isActive ? 'text-zinc-400' : 'text-slate-400'}`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          </div>

          <div className="bg-white border border-slate-200/50 shadow-[0_1px_3px_rgba(0,0,0,0.01),0_10px_30px_rgba(0,0,0,0.02)] p-5 rounded-2xl space-y-3">
            <div className="flex justify-between items-center text-xs font-bold text-slate-700 uppercase">
              <span>Avancement Global</span>
              <span className="text-[#121314]">
                {contractSigned ? '100%' : letterOfEngagementSigned ? '80%' : quoteStatus === 'In Progress' ? '50%' : diagnosticCompleted ? '30%' : '10%'}
              </span>
            </div>

            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#121314] rounded-full transition-all duration-500"
                style={{
                  width: contractSigned ? '100%' : letterOfEngagementSigned ? '80%' : quoteStatus === 'In Progress' ? '50%' : diagnosticCompleted ? '30%' : '10%'
                }}
              />
            </div>

            <p className="text-xs text-slate-400 font-semibold leading-relaxed">
              {contractSigned
                ? 'Projet officiellement lancé ! Suivez vos livrables.'
                : letterOfEngagementSigned
                ? 'Lettre signée ! En attente de rédaction du contrat.'
                : quoteStatus === 'In Progress'
                ? 'Devis en cours de validation technique et financière.'
                : diagnosticCompleted
                ? 'Diagnostic complété. Passez à l\'étape devis !'
                : 'Veuillez effectuer le diagnostic pour lancer votre projet.'}
            </p>
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 flex flex-col gap-6">
          
          {selectedTab === 'dashboard' && (
            <>
              {/* Fiche d'identité */}
              <div className="bg-white rounded-3xl p-8 shadow-[0_1px_3px_rgba(0,0,0,0.01),0_10px_30px_rgba(0,0,0,0.02)] border border-slate-200/50">
                <div className="mb-8">
                  <h2 className="text-xl font-extrabold text-slate-900 mb-1">Fiche d'identité de l'entreprise</h2>
                  <p className="text-sm text-slate-400 font-medium">Détails de votre compte</p>
                </div>

                <div className="flex flex-col">
                  {[
                    { label: 'Company', value: displayData.companyName || '-' },
                    { label: 'ICE (Identifiant Fiscal)', value: displayData.ice || '-' },
                    { label: 'Contact', value: displayData.contactName || '-' },
                    { label: 'Email', value: displayData.email || '-' },
                    { label: 'Phone', value: displayData.phone || '-' },
                    { label: 'N° CNSS & Salariés', value: displayData.cnssEmployees || '-' },
                    { label: "Chiffre d'Affaires", value: displayData.ca || '-' },
                    { label: "Secteur d'Activité", value: displayData.activity || '-', noBorder: true },
                  ].map((row, i) => (
                    <div key={i} className={`flex items-center justify-between py-4 ${!row.noBorder ? 'border-b border-slate-100' : ''}`}>
                      <span className="text-sm font-medium text-slate-500">{row.label}</span>
                      <span className="text-sm font-bold text-slate-900">{row.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Feuille de Route */}
              <RoadmapStepper steps={roadmapSteps} />
            </>
          )}

          {selectedTab === 'audit' && (
            <div className="bg-white rounded-[24px] p-8 lg:p-10 border border-slate-200/50 shadow-[0_1px_3px_rgba(0,0,0,0.01),0_10px_30px_rgba(0,0,0,0.02)] min-h-[600px]">
              
              {auditView === 'wizard' ? (
                <div className="flex flex-col gap-4">
                  <button onClick={() => setAuditView('list')} className="text-slate-500 hover:text-slate-800 text-sm font-bold flex items-center gap-2 mb-4 w-fit">
                    <ArrowLeft className="w-4 h-4" /> Retour
                  </button>
                  <DiagnosticWizard 
                    companyInfo={{ company_name: displayData.companyName, ice: displayData.ice, email: displayData.email, phone: displayData.phone }}
                    initialData={diagnosticInitialData}
                    initialStep={diagnosticInitialStep}
                    onComplete={async (diagData) => {
                      try {
                        let finalId = activeDiagnosticId;
                        if (!finalId) {
                          const { data: newDiag } = await supabase
                            .from('diagnostics')
                            .insert([{
                              client_id: displayData.id,
                              status: 'completed',
                              current_step: 999,
                              data: diagData
                            }])
                            .select().single();
                          if (newDiag) finalId = newDiag.id;
                        } else {
                          await supabase
                            .from('diagnostics')
                            .update({ status: 'completed', current_step: 999, data: diagData })
                            .eq('id', finalId);
                        }
                        setActiveDiagnosticId(finalId || null);
                        setPendingDiagnostic(JSON.stringify(diagData));
                        setAuditView('generator');
                      } catch (err) {
                        console.error(err);
                      }
                    }}
                    onSaveDraft={async (draftData, step) => {
                      if (!displayData.id) return;
                      try {
                        if (!activeDiagnosticId) {
                          const { data: newDiag } = await supabase
                            .from('diagnostics')
                            .insert([{
                              client_id: displayData.id,
                              status: 'draft',
                              current_step: step,
                              data: draftData
                            }])
                            .select().single();
                          if (newDiag) setActiveDiagnosticId(newDiag.id);
                        } else {
                          await supabase
                            .from('diagnostics')
                            .update({
                              current_step: step,
                              data: draftData
                            })
                            .eq('id', activeDiagnosticId);
                        }
                      } catch (err) {
                        console.error("Failed to save draft:", err);
                      }
                    }}
                    onClose={() => setAuditView('list')}
                    inline={true}
                  />
                </div>
              ) : auditView === 'generator' && pendingDiagnostic ? (
                <div className="flex flex-col gap-4">
                  <button onClick={() => setAuditView('list')} className="text-slate-500 hover:text-slate-800 text-sm font-bold flex items-center gap-2 mb-4 w-fit">
                    <ArrowLeft className="w-4 h-4" /> Retour
                  </button>
                  <div className="bg-white border border-slate-200/60 rounded-3xl p-6 shadow-sm overflow-hidden relative">
                    <ReportGenerator 
                      diagnosticJson={pendingDiagnostic}
                      diagnosticId={activeDiagnosticId}
                      onBack={() => setAuditView('list')}
                      onSuccess={async (url, filename, sizeKb) => {
                        // The ReportGenerator will handle uploading to Supabase Storage and updating the DB record.
                        // So we just need to reload the UI list.
                        await loadDiagnostics();
                      }}
                    />
                  </div>
                </div>
              ) : auditView === 'viewer' ? (
                <div className="flex flex-col gap-4">
                  <button onClick={() => setAuditView('list')} className="text-slate-500 hover:text-slate-800 text-sm font-bold flex items-center gap-2 mb-4 w-fit">
                    <ArrowLeft className="w-4 h-4" /> Retour
                  </button>
                  {(() => {
                    const currentDossier = dossiers.find(d => d.rawId === activeDiagnosticId);
                    if (!currentDossier) return <div className="text-slate-500 p-8 text-center">Dossier introuvable.</div>;
                    return (
                      <div className="bg-white border border-slate-200/60 rounded-3xl p-8 md:p-12 shadow-sm flex flex-col items-center justify-center text-center min-h-[450px]">
                        <div className="w-20 h-20 bg-teal-50 rounded-full flex items-center justify-center mb-6 border border-teal-100 shadow-sm">
                          <FileText className="w-10 h-10 text-teal-600" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 mb-2">Rapport de Diagnostic</h3>
                        <p className="text-sm text-slate-500 mb-1 font-semibold">Dossier {currentDossier.id}</p>
                        <p className="text-sm text-slate-500 mb-8 max-w-md">
                          {currentDossier.filename || 'Rapport.pdf'} • Généré le {currentDossier.date} {currentDossier.sizeKb ? `• ${Math.round(currentDossier.sizeKb)} Ko` : ''}
                        </p>
                        <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
                          <a 
                            href={currentDossier.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex-1 inline-flex items-center justify-center gap-2 bg-slate-100 text-slate-800 px-6 py-3.5 rounded-xl font-bold text-sm hover:bg-slate-200 transition-all border border-slate-200"
                          >
                            <ExternalLink className="w-4 h-4" />
                            Aperçu
                          </a>
                          <a 
                            href={currentDossier.url} 
                            download={currentDossier.filename || 'Rapport.pdf'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 inline-flex items-center justify-center gap-2 bg-[#121314] text-white px-6 py-3.5 rounded-xl font-bold text-sm hover:bg-black transition-all shadow-md"
                          >
                            <Download className="w-4 h-4" />
                            Télécharger le PDF
                          </a>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              ) : (
                <>
                  {/* Top Banner Button */}
                  <div 
                    onClick={() => {
                      setActiveDiagnosticId(null);
                      setDiagnosticInitialData(undefined);
                      setDiagnosticInitialStep(1);
                      setAuditView('wizard');
                    }}
                    className="mb-12 border border-slate-200/60 rounded-[20px] p-8 flex flex-col items-center justify-center text-center bg-slate-50/50 hover:bg-slate-50 transition-colors cursor-pointer group"
                  >
                    <button className="bg-white border border-slate-200 text-slate-800 font-bold px-6 py-2.5 rounded-full flex items-center gap-2 mb-4 group-hover:border-slate-300 transition-colors shadow-sm text-sm pointer-events-none">
                      <span className="text-teal-600 text-lg leading-none">+</span>
                      Nouveau Diagnostic
                    </button>
                    <p className="text-sm text-slate-500 font-medium max-w-[400px]">
                      Lancez une nouvelle évaluation pour analyser vos besoins et générer un devis subventionné.
                    </p>
                  </div>

                  {/* Section Header */}
                  <div className="mb-6 text-center">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Derniers diagnostics</h2>
                  </div>
                  
                  <hr className="border-slate-100 mb-8" />

                  {/* Folders Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {dossiers.length === 0 ? (
                      <div className="col-span-1 md:col-span-2 text-center py-12 text-slate-400 font-medium bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                        Aucun dossier d'audit pour le moment.
                      </div>
                    ) : (
                      dossiers.map((dossier: any) => (
                        <div key={dossier.id} onClick={() => { 
                          if(dossier.url) { 
                            setActiveDiagnosticId(dossier.rawId);
                            setAuditView('viewer');
                          } else if (dossier.status === 'draft') {
                            setActiveDiagnosticId(dossier.rawId);
                            setDiagnosticInitialData(dossier.data);
                            setDiagnosticInitialStep(dossier.step);
                            setAuditView('wizard');
                          } else {
                            setActiveDiagnosticId(dossier.rawId);
                            setPendingDiagnostic(JSON.stringify(dossier.data));
                            setAuditView('generator');
                          }
                        }} className="flex items-center gap-4 p-4 rounded-[16px] border border-slate-200/60 bg-white hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer group relative">
                          <div className="w-10 h-10 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center group-hover:bg-slate-100 transition-colors">
                            <Folder className="w-5 h-5 text-slate-600" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-base font-bold text-slate-900">
                              Dossier {dossier.id} 
                              {dossier.filename ? <span className="ml-2 text-[11px] bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Rapport généré</span> : ''}
                              {dossier.status === 'draft' ? <span className="ml-2 text-[11px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Brouillon (Étape {dossier.step})</span> : ''}
                              {dossier.status === 'completed' && !dossier.filename ? <span className="ml-2 text-[11px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">À générer</span> : ''}
                            </h3>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <svg className="w-3.5 h-3.5 text-slate-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>
                              </svg>
                              <span className="text-[12px] font-medium text-slate-500">Créé le {dossier.date}</span>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </>
              )}
            </div>
          )}

        </main>
      </div>
    </div>
  );
}