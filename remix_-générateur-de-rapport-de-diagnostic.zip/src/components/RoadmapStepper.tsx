import React from 'react';
import { Check, FileText, Layers, Compass } from 'lucide-react';

export type StepState = 'done' | 'active' | 'todo';

export interface RoadmapStep {
  stepName: string;
  title: string;
  badge: string;
  state: StepState;
  icon?: React.ReactNode;
  onSelect?: () => void;
}

interface RoadmapStepperProps {
  steps?: RoadmapStep[];
  title?: string;
  subtitle?: string;
}

const DEFAULT_STEPS: RoadmapStep[] = [
  { stepName: 'STEP 1', title: 'Audit',      badge: 'FAIT',    state: 'done',   icon: <Check className="w-5 h-5" strokeWidth={3} />, onSelect: () => {} },
  { stepName: 'STEP 2', title: 'Devis',      badge: 'À FAIRE', state: 'active', icon: <FileText className="w-[22px] h-[22px]" strokeWidth={2} />, onSelect: () => {} },
  { stepName: 'STEP 3', title: 'Engagement', badge: 'À FAIRE', state: 'todo' },
  { stepName: 'STEP 4', title: 'Mission',    badge: 'À FAIRE', state: 'todo' },
];

export function RoadmapStepper({
  steps = DEFAULT_STEPS,
  title = 'Feuille de Route & Progression',
  subtitle = 'Suivi de votre parcours de subvention et intégration',
}: RoadmapStepperProps) {
  return (
    <div className="rk-card bg-white rounded-2xl p-6 md:p-8 border border-slate-200/60 shadow-[0_1px_3px_rgba(0,0,0,0.01),0_10px_30px_rgba(0,0,0,0.02)]">
      <style>{`
        .rk-card { --rk-ink:#121314; --rk-ease:cubic-bezier(.4,0,.2,1); }

        .rk-node { animation: rk-rise .55s var(--rk-ease) both; animation-delay: calc(var(--i,0) * 90ms); }
        @keyframes rk-rise { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }

        .rk-circle { transition: transform .35s var(--rk-ease), box-shadow .35s var(--rk-ease), background-color .35s var(--rk-ease), border-color .35s var(--rk-ease); }

        .rk-node--done .rk-circle svg path {
          stroke-dasharray: 30; stroke-dashoffset: 30;
          animation: rk-draw .5s var(--rk-ease) .35s forwards;
        }
        @keyframes rk-draw { to { stroke-dashoffset: 0; } }

        .rk-node--active .rk-circle { animation: rk-pulse 2.6s var(--rk-ease) infinite; }
        @keyframes rk-pulse {
          0%,100% { box-shadow: 0 0 0 0 rgba(18,19,20,.18); }
          60%     { box-shadow: 0 0 0 9px rgba(18,19,20,0); }
        }
        .rk-node--active .rk-circle svg { animation: rk-float 2.8s ease-in-out infinite; }
        @keyframes rk-float { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-2px); } }

        .rk-node:not(:disabled) { cursor: pointer; }
        .rk-node:not(:disabled):hover { transform: translateY(-3px); }
        .rk-node:not(:disabled):hover .rk-circle { box-shadow: 0 8px 20px rgba(18,19,20,.16); }
        .rk-node:not(:disabled):active .rk-circle { transform: scale(.94); }

        @media (prefers-reduced-motion: reduce) {
          .rk-node, .rk-node--done .rk-circle svg path,
          .rk-node--active .rk-circle, .rk-node--active .rk-circle svg { animation: none !important; }
          .rk-node--done .rk-circle svg path { stroke-dashoffset: 0; }
        }
      `}</style>

      <div className="border-b border-slate-100 pb-4 mb-8">
        <h2 className="text-[17px] sm:text-lg font-bold text-slate-900 tracking-tight">{title}</h2>
        <p className="text-xs text-slate-400 font-medium mt-1">{subtitle}</p>
      </div>

      <div className="flex justify-between items-start gap-2 px-2 sm:px-6">
        {steps.map((s, idx) => {
          const isDone   = s.state === 'done';
          const isActive = s.state === 'active';
          const isTodo   = s.state === 'todo';
          const disabled = isTodo && !s.onSelect;

          const circle =
            isDone   ? 'bg-[#121314] text-white border-[3px] border-white ring-2 ring-[#121314] ring-offset-2 ring-offset-white shadow-md'
            : isActive ? 'bg-white text-[#121314] border-[3px] border-[#121314] ring-2 ring-[#121314]/15 ring-offset-2 ring-offset-white'
            : 'bg-slate-100 text-transparent border-[3px] border-white ring-1 ring-slate-200/70';

          const stepLabel = isTodo ? 'text-slate-300' : 'text-slate-400';
          const titleCls  = isTodo ? 'text-slate-300' : 'text-slate-900';

          const badgeCls =
            isDone   ? 'bg-slate-100 text-slate-700'
            : isActive ? 'bg-[#121314] text-white'
            : 'bg-slate-50 text-slate-300';

          const Tag = disabled ? 'div' : 'button';

          return (
            <Tag
              key={s.stepName}
              type={disabled ? undefined : 'button'}
              disabled={disabled}
              onClick={disabled ? undefined : s.onSelect}
              style={{ ['--i' as any]: idx }}
              className={`rk-node rk-node--${s.state} flex flex-col items-center w-20 sm:w-28 text-center bg-transparent border-none p-0 outline-none focus-visible:ring-2 focus-visible:ring-[#121314]/30 rounded-2xl ${disabled ? 'cursor-default' : ''}`}
            >
              <div className={`rk-circle w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center ${circle}`}>
                {isDone ? (
                  <Check className="w-5 h-5 sm:w-[22px] sm:h-[22px]" strokeWidth={3} />
                ) : isActive ? (
                  s.icon
                ) : null}
              </div>

              <div className="mt-3 space-y-1">
                <span className={`text-[10px] font-black uppercase tracking-wider block ${stepLabel}`}>{s.stepName}</span>
                <h4 className={`text-xs sm:text-[13px] font-black tracking-tight ${titleCls}`}>{s.title}</h4>
                <span className={`inline-block px-2.5 py-1 mt-1 rounded-md text-[8px] font-extrabold uppercase tracking-wider ${badgeCls}`}>
                  {s.badge}
                </span>
              </div>
            </Tag>
          );
        })}
      </div>
    </div>
  );
}