import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, CheckCircle2, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

/* ─── Form reference data ─── */

const SECTORS = [
  { id: 'tourisme', label: 'Tourisme' },
  { id: 'commerce', label: 'Commerce & Services' },
  { id: 'autre', label: 'Autre' },
];

const ACTIVITIES: Record<string, { id: string; label: string }[]> = {
  tourisme: [
    { id: 'hotel3', label: 'Hotel 3*' },
    { id: 'transport', label: 'Agence Transport' },
    { id: 'location', label: 'Location Voiture' },
    { id: 'autre-tourisme', label: 'Autre activité touristique' },
  ],
  commerce: [
    { id: 'ameublement', label: 'Ameublement Cuir' },
    { id: 'tapis', label: 'Artisanat Tapis' },
    { id: 'prothese', label: 'Prothèse Dentaire' },
    { id: 'livraison', label: 'Transport / Livraison' },
    { id: 'autre-commerce', label: 'Autre activité' },
  ],
};

/* ─── Component ─── */

interface EligibilityWizardProps {
  onComplete?: (data: any) => void;
  onNavigateToEspaceClient?: () => void;
}

export function EligibilityWizard({ onComplete, onNavigateToEspaceClient }: EligibilityWizardProps) {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // Step 1
  const [companyName, setCompanyName] = useState('');
  const [ice, setIce] = useState('');
  const [cnssEmployees, setCnssEmployees] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [ca, setCa] = useState('< 10M MAD');

  // Step 2
  const [sector, setSector] = useState('');
  const [activity, setActivity] = useState('');
  const [customActivity, setCustomActivity] = useState('');

  // Step 3
  const [hasWebsite, setHasWebsite] = useState('Oui');
  const [platforms, setPlatforms] = useState('');
  const [needs, setNeeds] = useState<string[]>([]);

  // Step 4 — access code
  const [accessCode, setAccessCode] = useState('');

  const TOTAL_STEPS = 3;
  const WIZARD_TITLES = [
    "Identification de l'établissement",
    'Secteur & Activité',
    'Besoins & Présence Digitale',
  ];

  const showCustomActivity =
    sector === 'autre' || activity === 'autre-tourisme' || activity === 'autre-commerce';

  const resolveActivityLabel = () => {
    if (customActivity.trim()) return customActivity.trim();
    const found = Object.values(ACTIVITIES)
      .flat()
      .find((entry) => entry.id === activity);
    return found ? found.label : '';
  };

  /* ─── Access code generation ─── */

  const generateAccessCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const randomStr = (length: number) =>
      Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${randomStr(3)}-${randomStr(4)}`;
  };

  /* ─── Navigation ─── */

  const handleNext = () => {
    if (step === 1 && (!companyName || !ice || !cnssEmployees || !email || !phone)) {
      alert('Veuillez remplir tous les champs obligatoires.');
      return;
    }
    if (step === 2 && !activity && !customActivity) {
      alert('Veuillez sélectionner ou décrire une activité.');
      return;
    }
    if (step < TOTAL_STEPS) setStep(step + 1);
  };

  const handleSubmit = async () => {
    setSubmitError('');
    setIsSubmitting(true);
    
    try {
      // Check if ICE already exists
      const { data: existingClient, error: searchError } = await supabase
        .from('clients')
        .select('ice')
        .eq('ice', ice)
        .maybeSingle();
        
      if (existingClient) {
        setSubmitError('Un dossier existe déjà pour ce numéro ICE.');
        setIsSubmitting(false);
        return;
      }
      
      const code = generateAccessCode();
      setAccessCode(code);
      
      const clientData = {
        company_name: companyName,
        ice: ice,
        access_code: code,
        cnss_employees: cnssEmployees,
        email: email,
        phone: phone,
        ca: ca,
        sector: sector,
        activity: activity,
        custom_activity: customActivity
      };
      
      const { error: insertError } = await supabase
        .from('clients')
        .insert([clientData]);
        
      if (insertError) throw insertError;

      onComplete?.({
        companyName,
        ice,
        cnssEmployees,
        email,
        phone,
        ca,
        sector,
        activity: resolveActivityLabel(),
        hasWebsite,
        platforms,
        needs,
        accessCode: code,
      });

      setStep(4);
    } catch (err: any) {
      console.error(err);
      setSubmitError(err.message || 'Erreur lors de la création du dossier.');
    } finally {
      setIsSubmitting(false);
    }
  };

  /* ─── Render ─── */

  return (
    <div className="flex items-center justify-center w-full text-slate-800 font-sans">
      <div className="w-full max-w-[800px] bg-white rounded-3xl shadow-[0_20px_50px_rgba(15,118,110,0.05)] overflow-hidden border border-slate-100/80">

        {/* Header + progress */}
        {step < 4 && (
          <div className="p-8 md:p-10 border-b border-slate-100/60">
            <header className="flex flex-col md:flex-row justify-between gap-4 items-start mb-6">
              <div>
                <p className="text-[#0f766e] uppercase tracking-[0.14em] text-[0.7rem] font-extrabold mb-2">
                  Formulaire d'éligibilité
                </p>
                <h1 className="text-2xl md:text-3xl font-extrabold text-slate-950 tracking-tight">
                  {step}. {WIZARD_TITLES[step - 1]}
                </h1>
              </div>
              <div className="bg-teal-50/60 text-[#0f766e] py-2 px-4 rounded-full font-bold whitespace-nowrap text-xs border border-teal-100/60 uppercase tracking-wider">
                Étape {step} / {TOTAL_STEPS}
              </div>
            </header>
            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#0f766e] transition-all duration-500 ease-out"
                style={{ width: `${(step / TOTAL_STEPS) * 100}%` }}
              />
            </div>
          </div>
        )}

        <div className="p-8 md:p-10">

          {/* ── Step 1 : Identification ── */}
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="grid gap-5 md:grid-cols-2">
                <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm">
                  <span>Raison Sociale</span>
                  <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="border border-slate-200 bg-slate-50 rounded-xl p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                </label>
                <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm">
                  <span>ICE (Identifiant Fiscal)</span>
                  <input type="text" value={ice} onChange={(e) => setIce(e.target.value)} className="border border-slate-200 bg-slate-50 rounded-xl p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                </label>
                <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm">
                  <span>N° CNSS & Effectif</span>
                  <input type="text" value={cnssEmployees} onChange={(e) => setCnssEmployees(e.target.value)} className="border border-slate-200 bg-slate-50 rounded-xl p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                </label>
                <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm">
                  <span>Email de contact</span>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="border border-slate-200 bg-slate-50 rounded-xl p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                </label>
                <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm">
                  <span>Téléphone</span>
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="border border-slate-200 bg-slate-50 rounded-xl p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                </label>
                <label className="flex flex-col gap-3 font-bold text-slate-700 text-sm">
                  <span>Tranche CA Annuel</span>
                  <div className="flex gap-6 mt-1">
                    <label className="flex items-center gap-2 cursor-pointer font-bold hover:text-[#0f766e] transition-colors">
                      <input type="radio" name="ca" value="< 10M MAD" checked={ca === '< 10M MAD'} onChange={(e) => setCa(e.target.value)} className="w-5 h-5 accent-[#0f766e]" />
                      &lt; 10M MAD
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer font-bold hover:text-[#0f766e] transition-colors">
                      <input type="radio" name="ca" value="> 10M MAD" checked={ca === '> 10M MAD'} onChange={(e) => setCa(e.target.value)} className="w-5 h-5 accent-[#0f766e]" />
                      &gt; 10M MAD
                    </label>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* ── Step 2 : Secteur & Activité ── */}
          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <h2 className="text-xs font-extrabold mb-4 uppercase text-slate-400 tracking-wider">Sélectionnez votre secteur</h2>
              <div className="grid gap-3 md:grid-cols-3 mb-8">
                {SECTORS.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { setSector(s.id); setActivity(''); setCustomActivity(''); }}
                    className={`text-center border rounded-xl p-4 cursor-pointer transition-all duration-200 font-extrabold text-sm ${
                      sector === s.id
                        ? 'border-[#0f766e] bg-teal-50/50 text-[#0f766e] ring-1 ring-[#0f766e]'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50/50'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {sector && (
                <div className="animate-in fade-in duration-300">
                  <h2 className="text-xs font-extrabold mb-4 uppercase text-slate-400 tracking-wider">Précisez votre activité</h2>
                  <div className="grid gap-3 md:grid-cols-2 mb-4">
                    {ACTIVITIES[sector]?.map((a) => (
                      <button
                        key={a.id}
                        onClick={() => { setActivity(a.id); setCustomActivity(''); }}
                        className={`text-left border rounded-xl p-4 cursor-pointer transition-all duration-200 font-bold text-sm ${
                          activity === a.id
                            ? 'border-[#0f766e] bg-teal-50/50 text-[#0f766e] ring-1 ring-[#0f766e]'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-50/50'
                        }`}
                      >
                        {a.label}
                      </button>
                    ))}
                  </div>
                  {showCustomActivity && (
                    <label className="flex flex-col gap-2 font-bold text-slate-700 animate-in fade-in mt-4 text-sm">
                      <span>Décrivez votre activité</span>
                      <textarea
                        rows={3}
                        value={customActivity}
                        onChange={(e) => setCustomActivity(e.target.value)}
                        placeholder="Ex: Organisation d'excursions..."
                        className="border border-slate-200 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] bg-slate-50 font-semibold"
                      />
                    </label>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ── Step 3 : Présence digitale & besoins ── */}
          {submitError && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl text-sm font-semibold">
                {submitError}
              </div>
            )}
          {step === 3 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="space-y-8">
                <div>
                  <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-4">Présence Digitale</h3>
                  <div className="space-y-4">
                    <p className="font-bold text-slate-700 text-sm">Avez-vous un site web ?</p>
                    <div className="flex gap-6">
                      <button onClick={() => setHasWebsite('Oui')} className={`flex-1 py-3 px-6 rounded-xl border transition-all font-bold text-sm cursor-pointer ${hasWebsite === 'Oui' ? 'border-[#0f766e] bg-teal-50/50 text-[#0f766e] ring-1 ring-[#0f766e]' : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100/50'}`}>Oui</button>
                      <button onClick={() => setHasWebsite('Non')} className={`flex-1 py-3 px-6 rounded-xl border transition-all font-bold text-sm cursor-pointer ${hasWebsite === 'Non' ? 'border-[#0f766e] bg-teal-50/50 text-[#0f766e] ring-1 ring-[#0f766e]' : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100/50'}`}>Non</button>
                    </div>
                  </div>
                  <label className="flex flex-col gap-2 font-bold text-slate-700 text-sm mt-5">
                    <span>Plateformes de vente (Booking, Airbnb, etc.)</span>
                    <input type="text" value={platforms} onChange={(e) => setPlatforms(e.target.value)} placeholder="Ex: Booking, Airbnb, Agence de voyage..." className="border border-slate-200 bg-slate-50 rounded-xl p-3 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e] transition-all font-semibold" />
                  </label>
                </div>

                <div>
                  <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider mb-4">Vos Besoins Prioritaires</h3>
                  <div className="grid gap-3">
                    {[
                      'Répondre instantanément sur WhatsApp aux demandes',
                      'Avoir des photos / vidéos professionnelles et vues de drone',
                      "Éviter les erreurs d'overbooking entre Booking et Airbnb",
                      "Suivi de l'activité en temps réel",
                      "Disponibilité de l'information de gestion (Stock, factures, créances...)",
                    ].map((need) => {
                      const isSelected = needs.includes(need);
                      return (
                        <label key={need} className={`flex items-start gap-3 cursor-pointer p-3.5 rounded-xl border transition-all duration-200 ${isSelected ? 'border-[#0f766e] bg-teal-50/40' : 'border-slate-200 bg-slate-50'}`}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              if (e.target.checked) setNeeds([...needs, need]);
                              else setNeeds(needs.filter((n) => n !== need));
                            }}
                            className="w-5 h-5 mt-0.5 rounded border-slate-300 text-[#0f766e] accent-[#0f766e]"
                          />
                          <span className={`leading-snug text-sm font-semibold ${isSelected ? 'text-slate-900 font-bold' : 'text-slate-600'}`}>{need}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── Step 4 : Success + access code ── */}
          {step === 4 && (
            <div className="animate-in fade-in zoom-in-95 duration-500 text-center py-6">
              <div className="w-20 h-20 bg-teal-100 text-[#0f766e] rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold mb-4 text-slate-900 tracking-tight">
                Dossier soumis avec succès !
              </h2>
              <p className="text-slate-500 mb-8 text-base">
                Un email de confirmation a été envoyé à <strong className="text-slate-800">{email}</strong>.
              </p>

              <div className="bg-slate-50 border border-slate-100 rounded-3xl p-8 text-left mb-6">
                <p className="text-xs uppercase tracking-widest text-slate-400 font-extrabold mb-4 text-center">
                  Votre code d'accès sécurisé
                </p>
                <div className="bg-white border border-slate-100 rounded-2xl p-6 flex justify-center items-center shadow-sm">
                  <code className="text-3xl md:text-4xl font-mono font-extrabold text-[#0f766e] tracking-[0.2em]">
                    {accessCode}
                  </code>
                </div>
                <p className="text-xs text-slate-400 mt-5 leading-relaxed text-center font-bold">
                  Notez précieusement ce code et votre numéro d'ICE. Ils vous seront demandés pour vous connecter.
                </p>
              </div>

              {onNavigateToEspaceClient && (
                <div className="bg-teal-50/30 border border-teal-100/80 rounded-3xl p-8 text-center space-y-6 flex flex-col items-center justify-center">
                  <div className="flex items-center justify-center gap-2">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0f766e] opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#0f766e]" />
                    </span>
                    <p className="text-[10px] uppercase tracking-wider text-[#0f766e] font-extrabold">Action requise immédiatement</p>
                  </div>
                  <div className="space-y-2 text-center max-w-xl">
                    <h4 className="text-lg font-bold text-slate-900">Compléter le Diagnostic & Cadrage Métier</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Pour valider définitivement votre éligibilité et permettre à nos équipes de configurer vos futurs outils de planification, veuillez vous connecter dès maintenant à l'Espace Client afin de remplir le diagnostic complet.
                    </p>
                  </div>
                  <button
                    onClick={onNavigateToEspaceClient}
                    className="w-full sm:w-auto bg-[#0f766e] text-white hover:bg-[#0d635c] px-6 py-3.5 rounded-xl font-bold text-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer group mx-auto"
                  >
                    <span>Accéder à l'Espace Client</span>
                    <span className="group-hover:translate-x-0.5 transition-transform">→</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ── Navigation footer ── */}
          {step < 4 && (
            <footer className="flex justify-between items-center mt-10 pt-6 border-t border-slate-100 gap-4">
              <button
                onClick={() => setStep(step - 1)}
                disabled={step === 1}
                className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-slate-800 px-5 py-3 rounded-xl hover:bg-slate-50 transition-colors disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Précédent
              </button>

              {step < TOTAL_STEPS ? (
                <button
                  onClick={handleNext}
                  className="flex items-center gap-2 bg-[#0f766e] hover:bg-[#0d635c] text-white rounded-xl py-3 px-8 font-bold text-xs uppercase tracking-wider transition-colors shadow-md shadow-teal-100 cursor-pointer"
                >
                  Suivant <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="flex items-center gap-2 bg-[#0f766e] hover:bg-[#0d635c] disabled:opacity-70 text-white rounded-xl py-3 px-8 font-bold text-xs uppercase tracking-wider transition-colors shadow-md shadow-teal-100 cursor-pointer"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  {isSubmitting ? 'Soumission...' : 'Soumettre le dossier'}
                </button>
              )}
            </footer>
          )}
        </div>
      </div>
    </div>
  );
}
